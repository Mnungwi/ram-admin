import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { DocumentService } from '../../../../core/services/domain.services'; // rekebisha idadi ya '../'
import Swal from 'sweetalert2';

const CATEGORIES = [
  'Contract',
  'Drawing',
  'Report',
  'Specification',
  'Permit',
  'Correspondence',
];
const REPORT_TYPES = [
  'Progress',
  'Test',
  'RFI',
  'Inspection',
  'Completion',
  'Environmental',
];
const DRAWING_TYPES = [
  'Structural',
  'Architectural',
  'Services',
];

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.css'],
})
export class DocumentsComponent implements OnInit {
  projectId = '';

  documents: any[] = [];
  filteredDocuments: any[] = [];
  loading = false;
  searchTerm = '';
  categoryFilter = '';

  categories = CATEGORIES;
  reportTypes = REPORT_TYPES;
  drawingTypes = DRAWING_TYPES;

  stats: any = {
    total: 0,
    Contract: 0,
    Drawing: 0,
    Report: 0,
    Specification: 0,
    Permit: 0,
    Correspondence: 0,
  };

  // Upload modal
  showUploadModal = false;
  uploadForm!: FormGroup;
  selectedFile: File | null = null;
  uploading = false;

  // Version history modal
  showVersionsModal = false;
  selectedDocument: any = null;
  versions: any[] = [];
  loadingVersions = false;
  newVersionFile: File | null = null;
  uploadingVersion = false;

  view: 'list' | 'grid' = 'list';

  constructor(
    private fb: FormBuilder,
    private docSvc: DocumentService,
    private route: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    // Documents ni routed child component (router-outlet) chini ya
    // ProjectDetailComponent — :id inatoka kwenye parent route, si @Input().
    const parent = this.route.parent;
    if (!parent) {
      console.error(
        'DocumentsComponent: hakuna parent route — hakiwezi kupata projectId',
      );
      return;
    }
    parent.paramMap.subscribe((params) => {
      const id = params.get('id');
      if (id) {
        this.projectId = id;
        this.load();
        this.loadStats();
      }
    });
  }

  load(): void {
    this.loading = true;
    this.docSvc.getAll(this.projectId).subscribe({
      next: (res: any) => {
        this.documents =
          res?.data?.rows || res?.data?.documents || res?.data || [];
        this.applyFilters();
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }

  loadStats(): void {
    this.docSvc.getStats(this.projectId).subscribe({
      next: (res: any) => {
        this.stats = res?.data?.stats || this.stats;
      },
    });
  }

  applyFilters(): void {
    const term = this.searchTerm.trim().toLowerCase();
    this.filteredDocuments = this.documents.filter((d) => {
      const matchSearch =
        !term ||
        d.title?.toLowerCase().includes(term) ||
        d.description?.toLowerCase().includes(term);
      const matchCategory =
        !this.categoryFilter || d.category === this.categoryFilter;
      return matchSearch && matchCategory;
    });
  }

  setCategoryFilter(cat: string): void {
    this.categoryFilter = this.categoryFilter === cat ? '' : cat;
    this.applyFilters();
  }

  formatFileSize(bytes: number): string {
    if (!bytes) return '—';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let i = 0;
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024;
      i++;
    }
    return `${size.toFixed(size < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
  }

  getCategoryIcon(category: string): string {
    const map: Record<string, string> = {
      Contract: 'fa-file-contract',
      Drawing: 'fa-drafting-compass',
      Report: 'fa-chart-line',
      Specification: 'fa-list-alt',
      Permit: 'fa-stamp',
      Correspondence: 'fa-envelope',
    };
    return map[category] || 'fa-file';
  }

  // ══════════════════════════════════════════════════════════
  // UPLOAD
  // ══════════════════════════════════════════════════════════

  openUploadModal(): void {
    this.uploadForm = this.fb.group({
      category: ['', Validators.required],
      reportType: [''],
      drawingType: [''],
      title: ['', Validators.required],
      description: [''],
    });
    this.selectedFile = null;

    // reportType/drawingType validators based on category
    this.uploadForm.get('category')?.valueChanges.subscribe((cat) => {
      const reportTypeCtrl = this.uploadForm.get('reportType');
      const drawingTypeCtrl = this.uploadForm.get('drawingType');

      if (cat === 'Report') {
        reportTypeCtrl?.setValidators([Validators.required]);
      } else {
        reportTypeCtrl?.clearValidators();
        reportTypeCtrl?.setValue('');
      }
      reportTypeCtrl?.updateValueAndValidity();

      if (cat === 'Drawing') {
        drawingTypeCtrl?.setValidators([Validators.required]);
      } else {
        drawingTypeCtrl?.clearValidators();
        drawingTypeCtrl?.setValue('');
      }
      drawingTypeCtrl?.updateValueAndValidity();
    });

    this.showUploadModal = true;
  }

  closeUploadModal(): void {
    this.showUploadModal = false;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile = input.files?.[0] || null;
  }

  get uf() {
    return this.uploadForm.controls;
  }

  submitUpload(): void {
    if (this.uploadForm.invalid || !this.selectedFile) {
      this.uploadForm.markAllAsTouched();
      if (!this.selectedFile) {
        Swal.fire('Info', 'Please select a file to upload.', 'info');
      }
      return;
    }

    this.uploading = true;
    const fd = new FormData();
    fd.append('file', this.selectedFile);
    fd.append('category', this.uploadForm.value.category);
    if (this.uploadForm.value.reportType)
      fd.append('reportType', this.uploadForm.value.reportType);
    if (this.uploadForm.value.drawingType)
      fd.append('drawingType', this.uploadForm.value.drawingType);
    fd.append('title', this.uploadForm.value.title);
    if (this.uploadForm.value.description)
      fd.append('description', this.uploadForm.value.description);

    this.docSvc.uploadDocument(this.projectId, fd).subscribe({
      next: (res: any) => {
        this.uploading = false;
        this.closeUploadModal();
        this.load();
        this.loadStats();
        Swal.fire({
          icon: 'success',
          title: res?.message || 'Document uploaded!',
          timer: 1800,
          showConfirmButton: false,
        });
      },
      error: (err: any) => {
        this.uploading = false;
        Swal.fire(
          'Error',
          err?.error?.message || 'Failed to upload document.',
          'error',
        );
      },
    });
  }

  // ══════════════════════════════════════════════════════════
  // DOWNLOAD / DELETE
  // ══════════════════════════════════════════════════════════

  download(doc: any): void {
    window.open(this.docSvc.getDownloadUrl(this.projectId, doc.id), '_blank');
  }

  deleteDoc(doc: any): void {
    Swal.fire({
      title: 'Delete Document?',
      text: `Delete "${doc.title}"? This cannot be undone.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, delete!',
    }).then((r) => {
      if (!r.isConfirmed) return;
      this.docSvc.delete(this.projectId, doc.id).subscribe({
        next: () => {
          this.load();
          this.loadStats();
          Swal.fire({
            icon: 'success',
            title: 'Deleted!',
            timer: 1200,
            showConfirmButton: false,
          });
        },
        error: (err: any) =>
          Swal.fire('Error', err?.error?.message || 'Failed.', 'error'),
      });
    });
  }

  // ══════════════════════════════════════════════════════════
  // VERSION HISTORY
  // ══════════════════════════════════════════════════════════

  openVersionsModal(doc: any): void {
    this.selectedDocument = doc;
    this.newVersionFile = null;
    this.loadingVersions = true;
    this.showVersionsModal = true;
    this.docSvc.getVersions(this.projectId, doc.id).subscribe({
      next: (res: any) => {
        this.versions = res?.data?.versions || [];
        this.loadingVersions = false;
      },
      error: () => {
        this.loadingVersions = false;
      },
    });
  }

  closeVersionsModal(): void {
    this.showVersionsModal = false;
    this.selectedDocument = null;
    this.versions = [];
  }

  onNewVersionFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.newVersionFile = input.files?.[0] || null;
  }

  uploadNewVersion(): void {
    if (!this.newVersionFile) {
      Swal.fire('Info', 'Select a file first.', 'info');
      return;
    }
    this.uploadingVersion = true;
    const fd = new FormData();
    fd.append('file', this.newVersionFile);
    this.docSvc
      .uploadNewVersion(this.projectId, this.selectedDocument.id, fd)
      .subscribe({
        next: (res: any) => {
          this.uploadingVersion = false;
          this.load();
          this.closeVersionsModal();
          Swal.fire({
            icon: 'success',
            title: res?.message || 'New version uploaded!',
            timer: 1800,
            showConfirmButton: false,
          });
        },
        error: (err: any) => {
          this.uploadingVersion = false;
          Swal.fire(
            'Error',
            err?.error?.message || 'Failed to upload new version.',
            'error',
          );
        },
      });
  }
}
