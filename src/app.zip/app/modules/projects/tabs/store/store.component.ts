import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  ProjectService,
  SupplierService,
  StoreService,
} from '../../../../core/services/domain.services';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-store',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css'],
})
export class StoreComponent implements OnInit, OnChanges {
  @Input() projectId = '';

  // Views
  activeTab: 'project' | 'central' | 'transactions' = 'project';

  // Project Store
  projectItems: any[] = [];
  filteredProjectItems: any[] = [];
  loadingProject = false;
  projectSearch = '';

  // Central Store
  centralItems: any[] = [];
  filteredCentralItems: any[] = [];
  loadingCentral = false;
  centralSearch = '';

  // Transactions
  transactions: any[] = [];
  loadingTransactions = false;

  // Requisitions (for issue)
  approvedRequisitions: any[] = [];
  requisitionOptions: any[] = [];

  // LPOs (for receive)
  sentLpos: any[] = [];
  lpoOptions: any[] = [];

  // Issue Modal
  showIssueModal = false;
  issueForm!: FormGroup;
  issuing = false;

  // Receive Modal
  showReceiveModal = false;
  receiveForm!: FormGroup;
  receiving = false;

  // Transfer from Central Modal
  showTransferModal = false;
  transferItems: {
    centralItemId: string;
    description: string;
    available: number;
    quantity: number;
  }[] = [];
  transferring = false;
  transferNotes = '';

  // Adjust Modal
  showAdjustModal = false;
  adjustForm!: FormGroup;
  adjusting = false;

  constructor(
    private fb: FormBuilder,
    private projectSvc: ProjectService,
    private storeSvc: StoreService,
  ) {}

  ngOnInit() {
    if (this.projectId) this.loadAll();
  }
  ngOnChanges() {
    if (this.projectId) this.loadAll();
  }

  loadAll() {
    this.loadProjectStore();
    this.loadCentralStore();
    this.loadTransactions();
    this.loadApprovedRequisitions();
    this.loadSentLpos();
  }

  // ── Project Store ─────────────────────────────────────────
  loadProjectStore() {
    this.loadingProject = true;
    this.storeSvc.getProjectStore(this.projectId).subscribe({
      next: (res: any) => {
        this.projectItems = res.data?.items || [];
        this.applyProjectFilter();
        this.loadingProject = false;
      },
      error: () => {
        this.loadingProject = false;
      },
    });
  }

  applyProjectFilter() {
    const s = this.projectSearch.toLowerCase();
    this.filteredProjectItems = s
      ? this.projectItems.filter((i) =>
          i.description?.toLowerCase().includes(s),
        )
      : [...this.projectItems];
  }

  // ── Central Store ─────────────────────────────────────────
  loadCentralStore() {
    this.loadingCentral = true;
    this.storeSvc.getCentralStore().subscribe({
      next: (res: any) => {
        this.centralItems = res.data?.items || [];
        this.applyCentralFilter();
        this.loadingCentral = false;
      },
      error: () => {
        this.loadingCentral = false;
      },
    });
  }

  applyCentralFilter() {
    const s = this.centralSearch.toLowerCase();
    this.filteredCentralItems = s
      ? this.centralItems.filter((i) =>
          i.description?.toLowerCase().includes(s),
        )
      : [...this.centralItems];
  }

  // ── Transactions ──────────────────────────────────────────
  loadTransactions() {
    this.loadingTransactions = true;
    this.storeSvc.getProjectTransactions(this.projectId).subscribe({
      next: (res: any) => {
        this.transactions = Array.isArray(res.data)
          ? res.data
          : res.data?.rows || [];
        this.loadingTransactions = false;
      },
      error: () => {
        this.loadingTransactions = false;
      },
    });
  }

  // ── Load approved RNs ─────────────────────────────────────
  loadApprovedRequisitions() {
    this.projectSvc.getRequisitions(this.projectId).subscribe({
      next: (res: any) => {
        const all = Array.isArray(res.data) ? res.data : res.data?.rows || [];
        this.approvedRequisitions = all.filter(
          (r: any) => r.status === 'approved',
        );
        this.requisitionOptions = this.approvedRequisitions.map((r: any) => ({
          value: r.id,
          label: `${r.requisitionNo} — ${r.siteLocation || ''}`,
        }));
      },
    });
  }

  // ── Load sent/partial LPOs ────────────────────────────────
  loadSentLpos() {
    this.projectSvc.getLpos(this.projectId).subscribe({
      next: (res: any) => {
        const all = Array.isArray(res.data)
          ? res.data
          : res.data?.rows || res.data?.lpos || [];
        this.sentLpos = all.filter((l: any) =>
          ['sent', 'partial'].includes(l.status),
        );
        this.lpoOptions = this.sentLpos.map((l: any) => ({
          value: l.id,
          label: `${l.lpoNo} — ${l.supplier?.name || ''}`,
        }));
      },
    });
  }

  // ── ISSUE from Store ──────────────────────────────────────
  openIssueModal() {
    if (!this.approvedRequisitions.length) {
      Swal.fire(
        'No Approved Requisitions',
        'There are no approved requisitions to issue.',
        'info',
      );
      return;
    }
    this.issueForm = this.fb.group({
      requisitionId: ['', Validators.required],
    });
    this.showIssueModal = true;
  }

  closeIssueModal() {
    this.showIssueModal = false;
  }

  onIssue() {
    if (this.issueForm.invalid) {
      this.issueForm.markAllAsTouched();
      return;
    }
    this.issuing = true;
    const { requisitionId } = this.issueForm.value;
    this.storeSvc
      .issueRequisition(this.projectId, { requisitionId })
      .subscribe({
        next: (res: any) => {
          this.issuing = false;
          this.closeIssueModal();
          this.loadAll();
          const {
            issuedFromProject = [],
            issuedFromCentral = [],
            notInStore = [],
          } = res.data || {};
          let html = '';
          if (issuedFromProject.length)
            html += `<p>✅ <strong>${issuedFromProject.length}</strong> item(s) issued from <b>Project Store</b></p>`;
          if (issuedFromCentral.length)
            html += `<p>🔄 <strong>${issuedFromCentral.length}</strong> item(s) transferred from <b>Central Store</b></p>`;
          if (notInStore.length) {
            html += `<p>⚠️ <strong>${notInStore.length}</strong> item(s) not in any store (pending LPO):</p><ul>`;
            notInStore.forEach((i: any) => {
              html += `<li>${i.description} — need ${i.required} ${i.unit || ''}</li>`;
            });
            html += '</ul>';
          }
          Swal.fire({
            icon: notInStore.length ? 'warning' : 'success',
            title: 'Issue Complete',
            html: html || 'Items issued successfully',
            confirmButtonText: 'OK',
          });
        },
        error: (err: any) => {
          this.issuing = false;
          Swal.fire('Error', err?.error?.message || 'Failed.', 'error');
        },
      });
  }

  // ── RECEIVE LPO to Store ──────────────────────────────────
  openReceiveModal() {
    if (!this.sentLpos.length) {
      Swal.fire(
        'No Pending LPOs',
        'There are no sent/partial LPOs to receive.',
        'info',
      );
      return;
    }
    this.receiveForm = this.fb.group({ lpoId: ['', Validators.required] });
    this.showReceiveModal = false;
    // Use LPO receive directly
    this.showReceiveModal = true;
  }

  closeReceiveModal() {
    this.showReceiveModal = false;
  }

  onReceive() {
    if (this.receiveForm.invalid) {
      this.receiveForm.markAllAsTouched();
      return;
    }
    this.receiving = true;
    const { lpoId } = this.receiveForm.value;
    // Navigate to LPO page for full receive workflow
    Swal.fire({
      icon: 'info',
      title: 'Go to LPO Page',
      text: 'Please use the Purchase Orders tab to mark items as received. The store will be updated automatically.',
      confirmButtonText: 'OK',
    });
    this.receiving = false;
    this.closeReceiveModal();
  }

  // ── TRANSFER from Central ─────────────────────────────────
  openTransferModal() {
    if (!this.centralItems.length) {
      Swal.fire(
        'Central Store Empty',
        'No items available in central store.',
        'info',
      );
      return;
    }
    this.transferItems = this.centralItems
      .filter((i) => parseFloat(i.quantity) > 0)
      .map((i) => ({
        centralItemId: i.id,
        description: i.description,
        available: parseFloat(i.quantity),
        quantity: 0,
      }));
    this.transferNotes = '';
    this.showTransferModal = true;
  }

  closeTransferModal() {
    this.showTransferModal = false;
  }

  onTransfer() {
    const itemsToTransfer = this.transferItems.filter((i) => i.quantity > 0);
    if (!itemsToTransfer.length) {
      Swal.fire('Error', 'Enter quantity for at least one item.', 'error');
      return;
    }
    const invalid = itemsToTransfer.find((i) => i.quantity > i.available);
    if (invalid) {
      Swal.fire(
        'Error',
        `Insufficient stock for ${invalid.description}. Available: ${invalid.available}`,
        'error',
      );
      return;
    }
    this.transferring = true;
    this.storeSvc
      .transferToProject(this.projectId, {
        items: itemsToTransfer,
        notes: this.transferNotes,
      })
      .subscribe({
        next: (res: any) => {
          this.transferring = false;
          this.closeTransferModal();
          this.loadAll();
          Swal.fire({
            icon: 'success',
            title: 'Transfer Complete',
            text: res.message,
            timer: 2000,
            showConfirmButton: false,
          });
        },
        error: (err: any) => {
          this.transferring = false;
          Swal.fire('Error', err?.error?.message || 'Failed.', 'error');
        },
      });
  }

  // ── ADJUST Project Store ──────────────────────────────────
  openAdjustModal() {
    this.adjustForm = this.fb.group({
      description: ['', Validators.required],
      unit: [''],
      quantity: ['', [Validators.required, Validators.min(0.01)]],
      type: ['in', Validators.required],
      notes: [''],
    });
    this.showAdjustModal = true;
  }

  closeAdjustModal() {
    this.showAdjustModal = false;
  }

  onAdjust() {
    if (this.adjustForm.invalid) {
      this.adjustForm.markAllAsTouched();
      return;
    }
    this.adjusting = true;
    this.storeSvc
      .adjustProject(this.projectId, this.adjustForm.value)
      .subscribe({
        next: () => {
          this.adjusting = false;
          this.closeAdjustModal();
          this.loadProjectStore();
          this.loadTransactions();
          Swal.fire({
            icon: 'success',
            title: 'Adjusted!',
            timer: 1500,
            showConfirmButton: false,
          });
        },
        error: (err: any) => {
          this.adjusting = false;
          Swal.fire('Error', err?.error?.message || 'Failed.', 'error');
        },
      });
  }

  // ── Transfer Remaining to Central (project complete) ──────
  transferToCentral() {
    Swal.fire({
      title: 'Transfer Remaining to Central Store?',
      text: 'All remaining items in this project store will be transferred to central store.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#1a56db',
      confirmButtonText: 'Yes, Transfer!',
      input: 'textarea',
      inputPlaceholder: 'Notes (optional)...',
    }).then((r) => {
      if (r.isConfirmed) {
        this.storeSvc
          .transferToCentral(this.projectId, { notes: r.value })
          .subscribe({
            next: (res: any) => {
              this.loadAll();
              Swal.fire({
                icon: 'success',
                title: 'Transferred!',
                text: res.message,
                timer: 2000,
                showConfirmButton: false,
              });
            },
            error: (err: any) =>
              Swal.fire('Error', err?.error?.message || 'Failed.', 'error'),
          });
      }
    });
  }

  // ── Helpers ───────────────────────────────────────────────
  getTransactionTypeClass(type: string): string {
    const m: any = {
      lpo_receive: 'badge-success',
      rn_issue: 'badge-danger',
      transfer_in: 'badge-primary',
      transfer_out: 'badge-warning',
      adjustment_in: 'badge-info',
      adjustment_out: 'badge-secondary',
      direct_receive: 'badge-success',
    };
    return m[type] || 'badge-secondary';
  }

  getTransactionIcon(type: string): string {
    const m: any = {
      lpo_receive: 'fa-arrow-down text-success',
      rn_issue: 'fa-arrow-up text-danger',
      transfer_in: 'fa-arrow-right text-primary',
      transfer_out: 'fa-arrow-left text-warning',
      adjustment_in: 'fa-plus text-info',
      adjustment_out: 'fa-minus text-secondary',
    };
    return m[type] || 'fa-exchange-alt';
  }

  getStockStatus(qty: number): string {
    if (qty <= 0) return 'out-of-stock';
    if (qty < 10) return 'low-stock';
    return 'in-stock';
  }

  get inStockCount(): number {
    return this.projectItems.filter((i) => +i.quantity > 0).length;
  }
  get lowStockCount(): number {
    return this.projectItems.filter((i) => +i.quantity > 0 && +i.quantity < 10)
      .length;
  }
  formatQty(n: any): string {
    return parseFloat(n || 0)
      .toFixed(2)
      .replace(/\.00$/, '');
  }
  get Math() {
    return Math;
  }
}
