import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Document } from '../../../../core/models/index';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.css'],
})
export class DocumentsComponent implements OnInit {
  projectId = '';
  documents: Document[] = [];
  filteredDocuments: Document[] = [];
  showModal = false;
  editMode = false;
  selectedDoc: Document | null = null;
  form!: FormGroup;
  searchTerm = '';
  filterCategory = 'All';
  viewMode: 'grid' | 'list' = 'list';
  currentPage = 1;
  pageSize = 10;

  categories = [
    'Contracts',
    'Drawings',
    'Reports',
    'Specifications',
    'Permits',
    'Photos',
    'Correspondences',
    'Others',
  ];

  constructor(
    private route: ActivatedRoute,
    private data: DataService,
    private fb: FormBuilder,
  ) {}

  ngOnInit() {
    this.route.parent?.params.subscribe((params) => {
      this.projectId = params['id'];
      this.data.getDocuments(this.projectId).subscribe((d) => {
        this.documents = d;
        this.applyFilters();
      });
    });
    this.initForm();
  }

  applyFilters() {
    let docs = [...this.documents];
    if (this.searchTerm)
      docs = docs.filter((d) =>
        d.name.toLowerCase().includes(this.searchTerm.toLowerCase()),
      );
    if (this.filterCategory !== 'All')
      docs = docs.filter((d) => d.category === this.filterCategory);
    this.filteredDocuments = docs;
    this.currentPage = 1;
  }

  get pagedDocs() {
    const s = (this.currentPage - 1) * this.pageSize;
    return this.filteredDocuments.slice(s, s + this.pageSize);
  }
  get totalPages() {
    return Math.ceil(this.filteredDocuments.length / this.pageSize);
  }
  get pages() {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }
  get Math() {
    return Math;
  }

  initForm(d?: Document) {
    this.form = this.fb.group({
      name: [d?.name || '', Validators.required],
      category: [d?.category || 'Reports', Validators.required],
      uploadDate: [d?.uploadDate || '', Validators.required],
      size: [d?.size || '', Validators.required],
      uploadedBy: [d?.uploadedBy || '', Validators.required],
      version: [d?.version || 'v1.0'],
      description: [d?.description || ''],
    });
  }

  openAddModal() {
    this.editMode = false;
    this.selectedDoc = null;
    this.initForm();
    this.showModal = true;
  }
  openEditModal(d: Document) {
    this.editMode = true;
    this.selectedDoc = d;
    this.initForm(d);
    this.showModal = true;
  }
  closeModal() {
    this.showModal = false;
  }

  onSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const val = this.form.value;
    const docData = {
      ...val,
      uploadedOn: val.uploadDate,
      fileSize: val.size,
    };
    if (this.editMode && this.selectedDoc) {
      this.data.updateDocument({ ...this.selectedDoc, ...docData });
      Swal.fire({
        icon: 'success',
        title: 'Document Updated!',
        timer: 1500,
        showConfirmButton: false,
      });
    } else {
      this.data.addDocument({
        id: this.data.generateId('DOC'),
        projectId: this.projectId,
        fileType: 'pdf',
        ...docData,
      });
      Swal.fire({
        icon: 'success',
        title: 'Document Added!',
        timer: 1500,
        showConfirmButton: false,
      });
    }
    this.closeModal();
  }

  deleteDocument(d: Document) {
    Swal.fire({
      title: 'Delete Document?',
      text: `Delete "${d.name}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, delete!',
    }).then((r) => {
      if (r.isConfirmed) {
        this.data.deleteDocument(d.id);
        Swal.fire({
          icon: 'success',
          title: 'Deleted!',
          timer: 1200,
          showConfirmButton: false,
        });
      }
    });
  }

  getFileIcon(d: Document): string {
    const ext = d.fileType || d.name?.split('.').pop() || '';
    if (ext === 'pdf') return 'fa-file-pdf text-danger';
    if (['doc', 'docx'].includes(ext)) return 'fa-file-word text-primary';
    if (['xls', 'xlsx'].includes(ext)) return 'fa-file-excel text-success';
    if (['dwg', 'dxf'].includes(ext)) return 'fa-drafting-compass text-info';
    if (['jpg', 'png', 'jpeg'].includes(ext))
      return 'fa-file-image text-warning';
    return 'fa-file text-secondary';
  }

  getCatClass(cat: string): string {
    const m: any = {
      Contracts: 'cat-contract',
      Drawings: 'cat-drawing',
      Reports: 'cat-report',
      Specifications: 'cat-spec',
      Permits: 'cat-permit',
    };
    return m[cat] || 'cat-other';
  }

  get f() {
    return this.form.controls;
  }
  get contractsCount() {
    return this.documents.filter((d) => d.category === 'Contracts').length;
  }
  get drawingsCount() {
    return this.documents.filter((d) => d.category === 'Drawings').length;
  }
  get reportsCount() {
    return this.documents.filter((d) => d.category === 'Reports').length;
  }
  get totalByCategory() {
    return this.categories
      .map((c) => ({
        category: c,
        count: this.documents.filter((d) => d.category === c).length,
      }))
      .filter((x) => x.count > 0);
  }
}
