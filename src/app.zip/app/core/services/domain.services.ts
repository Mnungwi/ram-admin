import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';

// ─── Projects Service ────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ProjectService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  getAll(params?: any) {
    return this.get<any>('/projects', params);
  }
  getOne(id: string) {
    return this.get<any>(`/projects/${id}`);
  }
  getOverview(id: string) {
    return this.get<any>(`/projects/${id}/overview`);
  }
  create(data: any) {
    return this.post<any>('/projects', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/projects/${id}`, data);
  }
  deleteProject(id: string) {
    return this.remove<any>(`/projects/${id}`);
  }

  getActivities(pid: string, params?: any) {
    return this.get<any>(`/projects/${pid}/activities`, params);
  }
  createActivity(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/activities`, data);
  }
  updateActivity(pid: string, aid: string, data: any) {
    return this.put<any>(`/projects/${pid}/activities/${aid}`, data);
  }
  deleteActivity(pid: string, aid: string) {
    return this.remove<any>(`/projects/${pid}/activities/${aid}`);
  }

  getTeam(pid: string) {
    return this.get<any>(`/projects/${pid}/team`);
  }
  addTeamMember(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/team`, data);
  }
  removeTeamMember(pid: string, uid: string) {
    return this.remove<any>(`/projects/${pid}/team/${uid}`);
  }

  getReports(pid: string, params?: any) {
    return this.get<any>(`/projects/${pid}/reports`, params);
  }
  createReport(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/reports`, data);
  }
  updateReport(pid: string, rid: string, data: any) {
    return this.put<any>(`/projects/${pid}/reports/${rid}`, data);
  }
  approveReport(pid: string, rid: string) {
    return this.post<any>(`/projects/${pid}/reports/${rid}/approve`, {});
  }

  getDocuments(pid: string) {
    return this.get<any>(`/projects/${pid}/documents`);
  }
  uploadDocument(pid: string, fd: FormData) {
    return this.upload<any>(`/projects/${pid}/documents`, fd);
  }

  // Contracts
  getContracts(pid: string) {
    return this.get<any>(`/projects/${pid}/contracts`);
  }
  createContract(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/contracts`, data);
  }
  updateContract(pid: string, id: string, data: any) {
    return this.put<any>(`/projects/${pid}/contracts/${id}`, data);
  }
  deleteContract(pid: string, id: string) {
    return this.remove<any>(`/projects/${pid}/contracts/${id}`);
  }

  // Purchase Orders

  // LPO
  getLpos(pid: string) {
    return this.get<any>(`/projects/${pid}/lpos`);
  }
  getLpo(pid: string, id: string) {
    return this.get<any>(`/projects/${pid}/lpos/${id}`);
  }
  createLpo(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos`, data);
  }
  updateLpo(pid: string, id: string, data: any) {
    return this.put<any>(`/projects/${pid}/lpos/${id}`, data);
  }
  deleteLpo(pid: string, id: string) {
    return this.remove<any>(`/projects/${pid}/lpos/${id}`);
  }
  createLpoFromRequisition(pid: string, reqId: string, data: any) {
    return this.post<any>(
      `/projects/${pid}/lpos/from-requisition/${reqId}`,
      data,
    );
  }

  // LPO Workflow
  submitLpo(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos/${id}/submit`, data);
  }
  approveLpo(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos/${id}/approve`, data);
  }
  sendLpo(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos/${id}/send`, data);
  }
  receiveLpo(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos/${id}/receive`, data);
  }
  cancelLpo(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos/${id}/cancel`, data);
  }

  // LPO Comments
  addLpoComment(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/lpos/${id}/comments`, data);
  }
  //supplier
  getProjectSuppliers(pid: string) {
    return this.get<any>(`/projects/${pid}/suppliers`);
  }
  addProjectSupplier(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/suppliers`, data);
  }
  updateProjectSupplier(pid: string, id: string, data: any) {
    return this.put<any>(`/projects/${pid}/suppliers/${id}`, data);
  }
  removeProjectSupplier(pid: string, id: string) {
    return this.remove<any>(`/projects/${pid}/suppliers/${id}`);
  }

  // Requisitions
  getRequisitions(pid: string, params?: any) {
    return this.get<any>(`/projects/${pid}/requisitions`);
  }
  getRequisition(pid: string, id: string) {
    return this.get<any>(`/projects/${pid}/requisitions/${id}`);
  }
  createRequisition(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions`, data);
  }
  updateRequisition(pid: string, id: string, data: any) {
    return this.put<any>(`/projects/${pid}/requisitions/${id}`, data);
  }
  deleteRequisition(pid: string, id: string) {
    return this.remove<any>(`/projects/${pid}/requisitions/${id}`);
  }

  // Workflow
  submitRequisition(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/submit`, data);
  }
  reviewRequisition(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/review`, data);
  }
  approveRequisition(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/approve`, data);
  }
  issueRequisition(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/issue`, data);
  }
  rejectRequisition(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/reject`, data);
  }
  cancelRequisition(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/cancel`, data);
  }

  // Comments
  addRequisitionComment(pid: string, id: string, data: any) {
    return this.post<any>(`/projects/${pid}/requisitions/${id}/comments`, data);
  }

  // // Project Technicians
  getProjectTechnicians(projectId: string, params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/projects/${projectId}/technicians${q}`);
  }
  assignToProject(projectId: string, data: any) {
    return this.post<any>(`/projects/${projectId}/technicians`, data);
  }
  updateAssignment(projectId: string, assignmentId: string, data: any) {
    return this.put<any>(`/projects/${projectId}/technicians/${assignmentId}`, data);
  }
  removeFromProject(projectId: string, assignmentId: string) {
    return this.remove<any>(`/projects/${projectId}/technicians/${assignmentId}`);
  }
}




// ── PRODUCT SERVICE ───────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ProductService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll(params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/products/all${q}`);
  }
  getList(params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/products${q}`);
  }
  getOne(id: string)                       { return this.get<any>(`/products/${id}`); }
  create(data: any)                        { return this.post<any>('/products', data); }
  update(id: string, data: any)            { return this.put<any>(`/products/${id}`, data); }
  delete(id: string)                       { return this.remove<any>(`/products/${id}`); }

  // Categories
  getCategories()                          { return this.get<any>('/products/categories'); }
  createCategory(data: any)                { return this.post<any>('/products/categories', data); }
  updateCategory(id: string, data: any)    { return this.put<any>(`/products/categories/${id}`, data); }
  deleteCategory(id: string)               { return this.remove<any>(`/products/categories/${id}`); }
}

// ── UNIT SERVICE ──────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class UnitService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll(params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/units${q}`);
  }
  getCategories()               { return this.get<any>('/units/categories'); }
  create(data: any)             { return this.post<any>('/units', data); }
  update(id: string, data: any) { return this.put<any>(`/units/${id}`, data); }
  delete(id: string)            { return this.remove<any>(`/units/${id}`); }
}

// ─── Finance Service ─────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class FinanceService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  getOverview(pid: string) {
    return this.get<any>(`/projects/${pid}/finance`);
  }
  getBudget(pid: string) {
    return this.get<any>(`/projects/${pid}/finance/budget`);
  }
  upsertBudget(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/finance/budget`, data);
  }

  getInvoices(pid: string, params?: any) {
    return this.get<any>(`/projects/${pid}/finance/invoices`, params);
  }
  createInvoice(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/finance/invoices`, data);
  }
  approveInvoice(pid: string, iid: string) {
    return this.post<any>(
      `/projects/${pid}/finance/invoices/${iid}/approve`,
      {},
    );
  }

  getPayments(pid: string, params?: any) {
    return this.get<any>(`/projects/${pid}/finance/payments`, params);
  }
  createPayment(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/finance/payments`, data);
  }
  approvePayment(pid: string, pid2: string) {
    return this.post<any>(
      `/projects/${pid}/finance/payments/${pid2}/approve`,
      {},
    );
  }

  getExpenses(pid: string, params?: any) {
    return this.get<any>(`/projects/${pid}/finance/expenses`, params);
  }
  createExpense(pid: string, data: any) {
    return this.post<any>(`/projects/${pid}/finance/expenses`, data);
  }
}

// ─── Letter Service ───────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class LetterService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  getAll(params?: any) {
    return this.get<any>('/letters', params);
  }
  getInbox(params?: any) {
    return this.get<any>('/letters/inbox', params);
  }
  getOne(id: string) {
    return this.get<any>(`/letters/${id}`);
  }
  create(data: any) {
    return this.post<any>('/letters', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/letters/${id}`, data);
  }
  deleteLetter(id: string) {
    return this.remove<any>(`/letters/${id}`);
  }
  submit(id: string) {
    return this.post<any>(`/letters/${id}/submit`, {});
  }
  approve(id: string) {
    return this.post<any>(`/letters/${id}/approve`, {});
  }
  send(id: string, data?: any) {
    return this.post<any>(`/letters/${id}/send`, data || {});
  }
  archive(id: string) {
    return this.post<any>(`/letters/${id}/archive`, {});
  }
  getStats(pid?: string) {
    const path = pid ? `/projects/${pid}/letters/stats` : '/letters/stats';
    return this.get<any>(path);
  }

  getPreviewUrl(id: string): string {
    return `${this.base}/letters/${id}/preview`;
  }

  downloadPdf(id: string): Observable<Blob> {
    return this.getBlob(`/letters/${id}/download`);
  }
}

// ─── Store Service ────────────────────────────────────────────────────────────
// @Injectable({ providedIn: 'root' })
// export class StoreService extends ApiService {
//   constructor(http: HttpClient) {
//     super(http);
//   }

//   getOverview(pid?: string) {
//     const p = pid ? `/projects/${pid}/store/overview` : '/store/overview';
//     return this.get<any>(p);
//   }

//   getItems(params?: any) {
//     return this.get<any>('/store', params);
//   }
//   getItem(id: string) {
//     return this.get<any>(`/store/items/${id}`);
//   }
//   createItem(data: any) {
//     return this.post<any>('/store', data);
//   }
//   updateItem(id: string, data: any) {
//     return this.put<any>(`/store/items/${id}`, data);
//   }
//   deleteItem(id: string) {
//     return this.remove<any>(`/store/items/${id}`);
//   }
//   adjustStock(id: string, data: any) {
//     return this.post<any>(`/store/items/${id}/adjust`, data);
//   }
//   getLedger(id: string, params?: any) {
//     return this.get<any>(`/store/items/${id}/ledger`, params);
//   }

//   getReceipts(params?: any) {
//     return this.get<any>('/store/receipts', params);
//   }
//   getReceipt(id: string) {
//     return this.get<any>(`/store/receipts/${id}`);
//   }
//   createReceipt(data: any) {
//     return this.post<any>('/store/receipts', data);
//   }

//   getIssues(params?: any) {
//     return this.get<any>('/store/issues', params);
//   }
//   getIssue(id: string) {
//     return this.get<any>(`/store/issues/${id}`);
//   }
//   createIssue(data: any) {
//     return this.post<any>('/store/issues', data);
//   }
//   approveIssue(id: string) {
//     return this.post<any>(`/store/issues/${id}/approve`, {});
//   }
//   dispatchIssue(id: string, data: any) {
//     return this.post<any>(`/store/issues/${id}/dispatch`, data);
//   }
//   returnIssue(id: string, data: any) {
//     return this.post<any>(`/store/issues/${id}/return`, data);
//   }
// }

// ─── User Service ─────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class UserService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  getAll(params?: any) {
    return this.get<any>('/users', params);
  }
  getOne(id: string) {
    return this.get<any>(`/users/${id}`);
  }
  create(data: any) {
    return this.post<any>('/users', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/users/${id}`, data);
  }
  deleteUser(id: string) {
    return this.remove<any>(`/users/${id}`);
  }
  assignRoles(id: string, data: any) {
    return this.post<any>(`/users/${id}/roles`, data);
  }
  getPermissions(id: string) {
    return this.get<any>(`/users/${id}/permissions`);
  }
  setPermissions(id: string, data: any) {
    return this.post<any>(`/users/${id}/permissions`, data);
  }
}

// ─── Role Service ─────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class RoleService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  getAll() {
    return this.get<any>('/roles');
  }
  getOne(id: string) {
    return this.get<any>(`/roles/${id}`);
  }
  create(data: any) {
    return this.post<any>('/roles', data);
  }
  // createPermission(data: any) {
  //   return this.post<any>('/permissions', data);
  // }
  createPermission(data: any) {
    return this.post<any>('/permissions', data);
  }
  updatePermission(id: string, data: any) {
    return this.put<any>(`/permissions/${id}`, data);
  }
  deletePermission(id: string) {
    return this.remove<any>(`/permissions/${id}`);
  }
  update(id: string, data: any) {
    return this.put<any>(`/roles/${id}`, data);
  }
  delete(id: string) {
    return this.remove<any>(`/roles/${id}`);
  }
  getAllPermissions() {
    return this.get<any>('/permissions');
  }
  syncPermissions(id: string, permissionIds: string[]) {
    return this.put<any>(`/roles/${id}/permissions`, { permissionIds });
  }
}

// ─── Supplier Service ─────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class SupplierService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }
  getAll() {
    return this.get<any>('/suppliers');
  }
  create(data: any) {
    return this.post<any>('/suppliers', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/suppliers/${id}`, data);
  }
  delete(id: string) {
    return this.remove<any>(`/suppliers/${id}`);
  }
}

@Injectable({ providedIn: 'root' })
export class PhaseService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  getAll() {
    return this.get<any>('/phases');
  }
  create(data: any) {
    return this.post<any>('/phases', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/phases/${id}`, data);
  }
  delete(id: string) {
    return this.remove<any>(`/phases/${id}`);
  }
}
// ─── Activity Type Service ────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ActivityTypeService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }
  getAll() {
    return this.get<any>('/activity-types');
  }
  create(data: any) {
    return this.post<any>('/activity-types', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/activity-types/${id}`, data);
  }
  delete(id: string) {
    return this.remove<any>(`/activity-types/${id}`);
  }
}

// ── STORE SERVICE ─────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class StoreService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  // Project Store
  getProjectStore(projectId: string)              { return this.get<any>(`/projects/${projectId}/store`); }
  getProjectTransactions(projectId: string)       { return this.get<any>(`/projects/${projectId}/store/transactions`); }
  issueRequisition(projectId: string, data: any)  { return this.post<any>(`/projects/${projectId}/store/issue-rn`, data); }
  transferToCentral(projectId: string, data: any) { return this.post<any>(`/projects/${projectId}/store/transfer-to-central`, data); }
  adjustProject(projectId: string, data: any)     { return this.post<any>(`/projects/${projectId}/store/adjust`, data); }

  // Central Store
  getCentralStore()                               { return this.get<any>('/store/central'); }
  getCentralTransactions()                        { return this.get<any>('/store/central/transactions'); }
  transferToProject(projectId: string, data: any) { return this.post<any>(`/store/central/transfer/${projectId}`, data); }
}

@Injectable({ providedIn: 'root' })
export class TechnicianService extends ApiService {
  constructor(http: HttpClient) {
    super(http);
  }

  // Categories
  getCategories() {
    return this.get<any>('/technicians/categories');
  }
  createCategory(data: any) {
    return this.post<any>('/technicians/categories', data);
  }
  updateCategory(id: string, data: any) {
    return this.put<any>(`/technicians/categories/${id}`, data);
  }
  deleteCategory(id: string) {
    return this.remove<any>(`/technicians/categories/${id}`);
  }

  // Technicians
  getAll(params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/technicians${q}`);
  }
  getOne(id: string) {
    return this.get<any>(`/technicians/${id}`);
  }
  create(data: any) {
    return this.post<any>('/technicians', data);
  }
  update(id: string, data: any) {
    return this.put<any>(`/technicians/${id}`, data);
  }
  delete(id: string) {
    return this.remove<any>(`/technicians/${id}`);
  }
  getReceipts(id: string, params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/technicians/${id}/receipts${q}`);
  }

  // Project Receipts
  getProjectReceipts(projectId: string, params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/projects/${projectId}/technician-receipts${q}`);
  }
  distribute(projectId: string, data: any) {
    return this.post<any>(
      `/projects/${projectId}/technician-receipts/distribute`,
      data,
    );
  }
  createReceipt(projectId: string, data: any) {
    return this.post<any>(`/projects/${projectId}/technician-receipts`, data);
  }
  acknowledge(projectId: string, receiptId: string, data?: any) {
    return this.post<any>(
      `/projects/${projectId}/technician-receipts/${receiptId}/acknowledge`,
      data || {},
    );
  }
  deleteReceipt(projectId: string, receiptId: string) {
    return this.remove<any>(
      `/projects/${projectId}/technician-receipts/${receiptId}`,
    );
  }

  // Ongeza kwenye TechnicianService:
  getProjectTechnicians(projectId: string, params?: any) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.get<any>(`/projects/${projectId}/technicians${q}`);
  }
  assignToProject(projectId: string, data: any) {
    return this.post<any>(`/projects/${projectId}/technicians`, data);
  }
  updateAssignment(projectId: string, assignmentId: string, data: any) {
    return this.put<any>(
      `/projects/${projectId}/technicians/${assignmentId}`,
      data,
    );
  }
  removeFromProject(projectId: string, assignmentId: string) {
    return this.remove<any>(
      `/projects/${projectId}/technicians/${assignmentId}`,
    );
  }
}


