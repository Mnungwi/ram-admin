import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { StoreService } from '../../core/services/domain.services';
import { AuthService } from '../../core/services/auth.service';

// ─── Store Receipts (GRN list) ────────────────────────────────────────────────
@Component({
  selector: 'app-store-receipts',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="page-header">
      <div><h1 class="page-title">Goods Received Notes</h1><p class="page-subtitle">All GRN records</p></div>
      <div class="d-flex gap-2">
        <a routerLink="/store" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Store</a>
        <a routerLink="/store/receive" class="btn btn-success btn-sm"><i class="bi bi-plus-lg"></i> New GRN</a>
      </div>
    </div>

    <div class="filters-bar mb-3">
      <select class="form-control" style="max-width:160px" [(ngModel)]="statusFilter" (ngModelChange)="load()">
        <option value="">All Status</option>
        <option value="received">Received</option>
        <option value="partial">Partial</option>
        <option value="rejected">Rejected</option>
        <option value="draft">Draft</option>
      </select>
    </div>

    <div *ngIf="loading()" class="loading-overlay"><div class="spinner-border"></div></div>

    <div *ngIf="!loading()" class="table-card">
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr><th>GRN No</th><th>Received Date</th><th>Delivery Note</th><th>Supplier</th><th>Items</th><th>Status</th><th>Received By</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let r of receipts()">
              <td style="font-family:monospace;font-size:12px;color:#16a34a;font-weight:600">{{ r.receiptNo }}</td>
              <td>{{ r.receivedDate | date:'dd MMM yyyy' }}</td>
              <td class="text-small text-muted">{{ r.deliveryNote || '—' }}</td>
              <td class="text-small">{{ r.supplier?.name || '—' }}</td>
              <td>
                <span class="badge" style="background:#f0fdf4;color:#166534">{{ r.lines?.length || 0 }} items</span>
              </td>
              <td><span class="badge badge-{{ r.status === 'received' ? 'completed' : r.status }}">{{ r.status }}</span></td>
              <td class="text-small text-muted">{{ r.receivedBy?.firstName }} {{ r.receivedBy?.lastName }}</td>
            </tr>
            <tr *ngIf="receipts().length === 0">
              <td colspan="7" class="text-center text-muted py-4">No receipts found</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class StoreReceiptsComponent implements OnInit {
  receipts = signal<any[]>([]);
  loading  = signal(true);
  statusFilter = '';

  constructor(private svc: StoreService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.svc.getReceipts({ status: this.statusFilter }).subscribe({
      next: (r: any) => { this.receipts.set(r.data || []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}

// ─── Store Issues (MIN list) ───────────────────────────────────────────────────
@Component({
  selector: 'app-store-issues',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="page-header">
      <div><h1 class="page-title">Material Issue Notes</h1><p class="page-subtitle">All MIN records</p></div>
      <div class="d-flex gap-2">
        <a routerLink="/store" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Store</a>
        <a routerLink="/store/issue" class="btn btn-warning btn-sm"><i class="bi bi-plus-lg"></i> New MIN</a>
      </div>
    </div>

    <div class="filters-bar mb-3">
      <select class="form-control" style="max-width:180px" [(ngModel)]="statusFilter" (ngModelChange)="load()">
        <option value="">All Status</option>
        <option value="draft">Draft</option>
        <option value="pending_approval">Pending Approval</option>
        <option value="approved">Approved</option>
        <option value="issued">Issued</option>
        <option value="returned">Returned</option>
      </select>
    </div>

    <div *ngIf="loading()" class="loading-overlay"><div class="spinner-border"></div></div>

    <div *ngIf="!loading()" class="table-card">
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr><th>MIN No</th><th>Issue Date</th><th>Issued To</th><th>Purpose</th><th>Items</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let i of issues()">
              <td style="font-family:monospace;font-size:12px;color:#f97316;font-weight:600">{{ i.issueNo }}</td>
              <td>{{ i.issueDate | date:'dd MMM yyyy' }}</td>
              <td class="text-medium">{{ i.issuedToName || i.issuedTo?.firstName || '—' }}</td>
              <td class="text-small text-muted" style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ i.purpose || '—' }}</td>
              <td>
                <span class="badge" style="background:#fff7ed;color:#9a3412">{{ i.lines?.length || 0 }} items</span>
              </td>
              <td>
                <span class="badge badge-{{ i.status === 'issued' ? 'completed' : i.status === 'pending_approval' ? 'pending' : i.status }}">
                  {{ i.status }}
                </span>
              </td>
              <td>
                <div class="d-flex gap-1">
                  <button *ngIf="i.status === 'draft' || i.status === 'pending_approval'"
                          class="action-btn success" title="Approve" (click)="approve(i)">
                    <i class="bi bi-check-lg"></i>
                  </button>
                  <button *ngIf="i.status === 'approved'"
                          class="btn btn-warning btn-sm" (click)="dispatch(i)">
                    <i class="bi bi-box-arrow-right"></i> Dispatch
                  </button>
                </div>
              </td>
            </tr>
            <tr *ngIf="issues().length === 0">
              <td colspan="7" class="text-center text-muted py-4">No issue notes found</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class StoreIssuesComponent implements OnInit {
  issues  = signal<any[]>([]);
  loading = signal(true);
  statusFilter = '';

  constructor(private svc: StoreService, public auth: AuthService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.svc.getIssues({ status: this.statusFilter }).subscribe({
      next: (r: any) => { this.issues.set(r.data || []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
  approve(i: any): void {
    this.svc.approveIssue(i.id).subscribe({ next: () => this.load() });
  }
  dispatch(i: any): void {
    const lines = (i.lines || []).map((l: any) => ({ issueLineId: l.id, qtyIssued: l.qtyRequested }));
    this.svc.dispatchIssue(i.id, { lines }).subscribe({ next: () => this.load() });
  }
}

// ─── Stock Ledger ─────────────────────────────────────────────────────────────
@Component({
  selector: 'app-store-ledger',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-header">
      <div>
        <h1 class="page-title">Stock Ledger</h1>
        <p class="page-subtitle" *ngIf="item()">
          {{ item().name }} ({{ item().itemCode }}) · Current stock:
          <strong>{{ item().stockOnHand }} {{ item().unit }}</strong>
        </p>
      </div>
      <a routerLink="/store/items" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Items</a>
    </div>

    <div *ngIf="loading()" class="loading-overlay"><div class="spinner-border"></div></div>

    <div *ngIf="!loading()" class="table-card">
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr><th>Date</th><th>Type</th><th>Qty</th><th>Balance After</th><th>Unit Cost</th><th>Reference</th><th>By</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let t of transactions()">
              <td class="text-small text-muted">{{ t.createdAt | date:'dd MMM yyyy, HH:mm' }}</td>
              <td>
                <span class="badge" [style.background]="getTypeBg(t.type)" [style.color]="getTypeColor(t.type)">
                  {{ t.type }}
                </span>
              </td>
              <td>
                <span [style.color]="t.qty > 0 ? '#16a34a' : '#dc2626'" style="font-weight:600">
                  {{ t.qty > 0 ? '+' : '' }}{{ t.qty }}
                </span>
              </td>
              <td class="fw-600">{{ t.balanceAfter }}</td>
              <td class="text-small">{{ t.unitCost | number:'1.0-0' }}</td>
              <td class="text-small text-muted">{{ t.referenceType || '—' }}</td>
              <td class="text-small text-muted">{{ t.createdBy?.firstName }}</td>
            </tr>
            <tr *ngIf="transactions().length === 0">
              <td colspan="7" class="text-center text-muted py-4">No transactions found</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class StoreLedgerComponent implements OnInit {
  item         = signal<any>(null);
  transactions = signal<any[]>([]);
  loading      = signal(true);

  constructor(private svc: StoreService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.svc.getItem(id).subscribe({ next: (r: any) => this.item.set(r.data?.item || r.data) });
    this.svc.getLedger(id).subscribe({
      next: (r: any) => { this.transactions.set(r.data || []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  getTypeBg(t: string): string {
    const map: Record<string, string> = { receipt:'#dcfce7', issue:'#fed7aa', return:'#dbeafe', adjustment:'#f3f4f6', transfer:'#ede9fe' };
    return map[t] || '#f3f4f6';
  }
  getTypeColor(t: string): string {
    const map: Record<string, string> = { receipt:'#166534', issue:'#9a3412', return:'#1e40af', adjustment:'#374151', transfer:'#6d28d9' };
    return map[t] || '#374151';
  }
}

// ─── Store Issue (MIN form) ───────────────────────────────────────────────────
@Component({
  selector: 'app-store-issue',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ReactiveFormsModule],
  template: `
    <div class="page-header">
      <div><h1 class="page-title">Issue Items — MIN</h1><p class="page-subtitle">Create a Material Issue Note</p></div>
      <a routerLink="/store" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back</a>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <form [formGroup]="form" (ngSubmit)="onSubmit()">
          <div *ngIf="error()" class="alert alert-danger mb-3">{{ error() }}</div>

          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">Issue Details</h5></div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Issue Date *</label>
                  <input type="date" class="form-control" formControlName="issueDate">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Issued To</label>
                  <input class="form-control" formControlName="issuedToName" placeholder="Person name">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Purpose</label>
                  <input class="form-control" formControlName="purpose" placeholder="e.g. Foundation works">
                </div>
              </div>
              <div>
                <label class="form-label">Notes</label>
                <textarea class="form-control" formControlName="notes" rows="2"></textarea>
              </div>
            </div>
          </div>

          <div class="card mb-3">
            <div class="card-header">
              <h5 class="card-title">Items to Issue</h5>
              <button type="button" class="btn btn-outline-primary btn-sm" (click)="addLine()">
                <i class="bi bi-plus-lg"></i> Add Item
              </button>
            </div>
            <div class="card-body">
              <div *ngFor="let line of linesArray.controls; let i = index"
                   class="grn-line" [formGroup]="getLine(i)">
                <div class="grn-line-num">{{ i + 1 }}</div>
                <div class="row" style="flex:1">
                  <div class="col-md-6 mb-2">
                    <label class="form-label-sm">Item *</label>
                    <select class="form-control form-control-sm" formControlName="storeItemId">
                      <option value="">— Select Item —</option>
                      <option *ngFor="let item of storeItems()" [value]="item.id">
                        {{ item.itemCode }} – {{ item.name }} ({{ item.stockOnHand }} {{ item.unit }})
                      </option>
                    </select>
                  </div>
                  <div class="col-md-3 mb-2">
                    <label class="form-label-sm">Qty Requested *</label>
                    <input type="number" class="form-control form-control-sm" formControlName="qtyRequested" min="0.001">
                  </div>
                  <div class="col-md-3 mb-2">
                    <label class="form-label-sm">Unit Cost</label>
                    <input type="number" class="form-control form-control-sm" formControlName="unitCost" min="0">
                  </div>
                </div>
                <button type="button" class="action-btn danger mt-3" (click)="removeLine(i)">
                  <i class="bi bi-trash"></i>
                </button>
              </div>
              <div *ngIf="linesArray.length === 0" class="text-muted text-center py-3">
                Add items to this issue note
              </div>
            </div>
          </div>

          <div class="d-flex gap-2 justify-content-end">
            <a routerLink="/store" class="btn btn-outline-secondary">Cancel</a>
            <button type="submit" class="btn btn-warning" [disabled]="saving() || linesArray.length === 0">
              <span *ngIf="saving()" class="spinner-border spinner-border-sm mr-2"></span>
              <i class="bi bi-box-arrow-right"></i> Create MIN
            </button>
          </div>
        </form>
      </div>

      <div class="col-lg-4">
        <div class="card" style="position:sticky;top:80px">
          <div class="card-header"><h5 class="card-title">MIN Workflow</h5></div>
          <div class="card-body">
            <div class="timeline">
              <div class="timeline-item">
                <div class="timeline-title">Create MIN (Draft)</div>
                <div class="timeline-body">Request items from the store</div>
              </div>
              <div class="timeline-item">
                <div class="timeline-title">Approve</div>
                <div class="timeline-body">Authorised person approves the request</div>
              </div>
              <div class="timeline-item">
                <div class="timeline-title">Dispatch</div>
                <div class="timeline-body">Items issued — stock deducted automatically</div>
              </div>
              <div class="timeline-item">
                <div class="timeline-title">Return (optional)</div>
                <div class="timeline-body">Unused items returned — stock restored</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .grn-line { display:flex;align-items:flex-start;gap:10px;padding:12px;background:#f9fafb;border-radius:8px;border:1px solid #e5e7eb;margin-bottom:8px; }
    .grn-line-num { width:24px;height:24px;background:#f97316;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff;flex-shrink:0;margin-top:22px; }
    .form-label-sm { font-size:11px;font-weight:600;color:#6b7280;margin-bottom:3px;display:block; }
  `]
})
export class StoreIssueComponent implements OnInit {
  form!: FormGroup;
  storeItems = signal<any[]>([]);
  saving     = signal(false);
  error      = signal('');

  get linesArray(): FormArray { return this.form.get('lines') as FormArray; }
  getLine(i: number): FormGroup { return this.linesArray.at(i) as FormGroup; }

  constructor(
    private svc: StoreService,
    private router: Router,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      issueDate:    [new Date().toISOString().split('T')[0], Validators.required],
      issuedToName: [''],
      purpose:      [''],
      notes:        [''],
      lines:        this.fb.array([])
    });
    this.svc.getItems({ limit: 200 }).subscribe({
      next: (r: any) => this.storeItems.set(r.data || [])
    });
    this.addLine();
  }

  addLine(): void {
    this.linesArray.push(this.fb.group({
      storeItemId:  ['', Validators.required],
      qtyRequested: [1, [Validators.required, Validators.min(0.001)]],
      unitCost:     [0]
    }));
  }

  removeLine(i: number): void { this.linesArray.removeAt(i); }

  onSubmit(): void {
    if (this.form.invalid || !this.linesArray.length) return;
    this.saving.set(true);
    this.svc.createIssue(this.form.value).subscribe({
      next: () => this.router.navigate(['/store/issues']),
      error: err => { this.saving.set(false); this.error.set(err.error?.message || 'Failed to create MIN'); }
    });
  }
}
