import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StoreService } from '../../core/services/domain.services';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-store-items',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ReactiveFormsModule],
  template: `
    <div class="page-header">
      <div>
        <h1 class="page-title">Store Items</h1>
        <p class="page-subtitle">All materials and equipment in inventory</p>
      </div>
      <div class="d-flex gap-2">
        <a routerLink="/store" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Store</a>
        @if (auth.hasPermission('store:create')) {
          <button class="btn btn-primary btn-sm" (click)="showForm.set(true)">
            <i class="bi bi-plus-lg"></i> Add Item
          </button>
        }
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar mb-3">
      <div class="input-group" style="max-width:260px">
        <div class="input-group-prepend"><span class="input-group-text"><i class="bi bi-search"></i></span></div>
        <input class="form-control" placeholder="Search items..." [(ngModel)]="search" (ngModelChange)="load()">
      </div>
      <select class="form-control" style="max-width:160px" [(ngModel)]="categoryFilter" (ngModelChange)="load()">
        <option value="">All Categories</option>
        @for (c of categories; track c) { <option [value]="c">{{ c }}</option> }
      </select>
      <div class="form-check ml-2" style="display:flex;align-items:center;gap:6px">
        <input type="checkbox" class="form-check-input" id="lowStock" [(ngModel)]="belowReorder" (ngModelChange)="load()">
        <label class="form-check-label text-small" for="lowStock">Low stock only</label>
      </div>
    </div>

    @if (loading()) {
      <div class="loading-overlay"><div class="spinner-border"></div></div>
    } @else {
      <div class="table-card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr><th>Code</th><th>Name</th><th>Category</th><th>Unit</th><th>Stock On Hand</th><th>Reorder Level</th><th>Unit Cost (TZS)</th><th>Location</th><th></th></tr>
            </thead>
            <tbody>
              @for (item of items(); track item.id) {
                <tr>
                  <td style="font-family:monospace;font-size:12px;color:#2563eb">{{ item.itemCode }}</td>
                  <td style="font-weight:500;color:#111827">{{ item.name }}</td>
                  <td class="text-small text-muted">{{ item.category }}</td>
                  <td class="text-small">{{ item.unit }}</td>
                  <td>
                    <div class="d-flex align-items-center gap-2">
                      <span [class]="getStockClass(item)" style="font-weight:600; font-size:15px">{{ item.stockOnHand }}</span>
                      <span class="text-muted text-small">{{ item.unit }}</span>
                      @if (item.stockOnHand == 0) {
                        <span class="badge badge-overdue" style="font-size:10px">Empty</span>
                      } @else if (item.stockOnHand <= item.reorderLevel) {
                        <span class="badge badge-pending" style="font-size:10px">Low</span>
                      }
                    </div>
                    <div class="progress mt-1" style="height:3px; width:80px">
                      <div class="progress-bar"
                           [style.width.%]="getStockPct(item)"
                           [style.background]="getStockColor(item)"></div>
                    </div>
                  </td>
                  <td class="text-small text-muted">{{ item.reorderLevel }} {{ item.unit }}</td>
                  <td class="text-medium">{{ item.unitCost | number:'1.0-0' }}</td>
                  <td class="text-small text-muted">{{ item.location || '—' }}</td>
                  <td>
                    <div class="d-flex gap-1">
                      <a [routerLink]="['/store/items', item.id, 'ledger']" class="action-btn" title="View ledger">
                        <i class="bi bi-journal-text"></i>
                      </a>
                      @if (auth.hasPermission('store:adjust')) {
                        <button class="action-btn" title="Adjust stock" (click)="openAdjust(item)">
                          <i class="bi bi-sliders"></i>
                        </button>
                      }
                      @if (auth.hasPermission('store:update')) {
                        <button class="action-btn" title="Edit" (click)="editItem(item)">
                          <i class="bi bi-pencil"></i>
                        </button>
                      }
                    </div>
                  </td>
                </tr>
              }
              @if (items().length === 0) {
                <tr><td colspan="9" class="text-center text-muted py-4">No items found</td></tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    }

    <!-- Add/Edit Item Modal -->
    @if (showForm()) {
      <div class="modal-backdrop-custom" (click)="closeForm()"></div>
      <div class="modal-custom">
        <div class="modal-content" style="max-width:560px">
          <div class="modal-header">
            <h5 class="modal-title">{{ editingItem() ? 'Edit Item' : 'Add Store Item' }}</h5>
            <button class="close" (click)="closeForm()"><span>&times;</span></button>
          </div>
          <div class="modal-body">
            <form [formGroup]="itemForm">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Item Code *</label>
                  <input class="form-control" formControlName="itemCode" placeholder="CEM-001">
                </div>
                <div class="col-md-8 mb-3">
                  <label class="form-label">Name *</label>
                  <input class="form-control" formControlName="name" placeholder="Cement (50kg bags)">
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Category</label>
                  <input class="form-control" formControlName="category" placeholder="Building Materials">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label">Unit *</label>
                  <input class="form-control" formControlName="unit" placeholder="bags">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label">Unit Cost (TZS)</label>
                  <input type="number" class="form-control" formControlName="unitCost">
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Reorder Level</label>
                  <input type="number" class="form-control" formControlName="reorderLevel" placeholder="20">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Storage Location</label>
                  <input class="form-control" formControlName="location" placeholder="Warehouse A - Shelf 3">
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline-secondary" (click)="closeForm()">Cancel</button>
            <button class="btn btn-primary" (click)="saveItem()" [disabled]="saving()">
              @if (saving()) { <span class="spinner-border spinner-border-sm mr-2"></span> }
              {{ editingItem() ? 'Update' : 'Add Item' }}
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Adjust Stock Modal -->
    @if (adjustItem()) {
      <div class="modal-backdrop-custom" (click)="adjustItem.set(null)"></div>
      <div class="modal-custom">
        <div class="modal-content" style="max-width:400px">
          <div class="modal-header">
            <h5 class="modal-title">Adjust Stock: {{ adjustItem()!.name }}</h5>
            <button class="close" (click)="adjustItem.set(null)"><span>&times;</span></button>
          </div>
          <div class="modal-body">
            <div class="alert alert-info text-small">
              Current stock: <strong>{{ adjustItem()!.stockOnHand }} {{ adjustItem()!.unit }}</strong>
            </div>
            <div class="mb-3">
              <label class="form-label">Adjustment Qty *</label>
              <input type="number" class="form-control" [(ngModel)]="adjustQty" placeholder="e.g. -5 (remove) or +10 (add)">
              <div class="text-muted text-small mt-1">Positive = add to stock · Negative = remove from stock</div>
            </div>
            <div class="mb-3">
              <label class="form-label">Reason</label>
              <input class="form-control" [(ngModel)]="adjustReason" placeholder="e.g. Damaged goods, stocktake correction">
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline-secondary" (click)="adjustItem.set(null)">Cancel</button>
            <button class="btn btn-primary" (click)="doAdjust()" [disabled]="saving()">Apply Adjustment</button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .modal-backdrop-custom {
      position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 1040;
    }
    .modal-custom {
      position: fixed; inset: 0; z-index: 1050;
      display: flex; align-items: center; justify-content: center; padding: 16px;
    }
    .modal-content { width: 100%; }
  `]
})
export class StoreItemsComponent implements OnInit {
  items = signal<any[]>([]);
  loading = signal(true);
  saving = signal(false);
  showForm = signal(false);
  editingItem = signal<any>(null);
  adjustItem = signal<any>(null);
  adjustQty = 0;
  adjustReason = '';
  search = '';
  categoryFilter = '';
  belowReorder = false;

  categories = ['Building Materials', 'Electrical', 'Plumbing', 'HVAC', 'Safety', 'Tools', 'Other'];

  itemForm: FormGroup;

  constructor(private svc: StoreService, public auth: AuthService, private fb: FormBuilder) {
    this.itemForm = this.fb.group({
      itemCode:     ['', Validators.required],
      name:         ['', Validators.required],
      category:     [''],
      unit:         ['pcs', Validators.required],
      unitCost:     [0],
      currency:     ['TZS'],
      reorderLevel: [0],
      location:     ['']
    });
  }

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.svc.getItems({ search: this.search, category: this.categoryFilter, belowReorder: this.belowReorder }).subscribe({
      next: (res: any) => { this.items.set(res.data || []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  editItem(item: any): void {
    this.editingItem.set(item);
    this.itemForm.patchValue(item);
    this.showForm.set(true);
  }

  closeForm(): void {
    this.showForm.set(false);
    this.editingItem.set(null);
    this.itemForm.reset({ unit: 'pcs', unitCost: 0, reorderLevel: 0, currency: 'TZS' });
  }

  saveItem(): void {
    if (this.itemForm.invalid) return;
    this.saving.set(true);
    const obs = this.editingItem()
      ? this.svc.updateItem(this.editingItem().id, this.itemForm.value)
      : this.svc.createItem(this.itemForm.value);
    obs.subscribe({
      next: () => { this.saving.set(false); this.closeForm(); this.load(); },
      error: () => this.saving.set(false)
    });
  }

  openAdjust(item: any): void {
    this.adjustItem.set(item);
    this.adjustQty = 0;
    this.adjustReason = '';
  }

  doAdjust(): void {
    if (!this.adjustQty) return;
    this.saving.set(true);
    this.svc.adjustStock(this.adjustItem().id, { qty: this.adjustQty, reason: this.adjustReason }).subscribe({
      next: () => { this.saving.set(false); this.adjustItem.set(null); this.load(); },
      error: () => this.saving.set(false)
    });
  }

  getStockClass(item: any): string {
    if (item.stockOnHand === 0) return 'stock-empty';
    if (item.stockOnHand <= item.reorderLevel) return 'stock-low';
    return 'stock-ok';
  }

  getStockPct(item: any): number {
    if (!item.maxLevel) return Math.min(100, (item.stockOnHand / Math.max(item.reorderLevel * 2, 1)) * 100);
    return Math.min(100, (item.stockOnHand / item.maxLevel) * 100);
  }

  getStockColor(item: any): string {
    if (item.stockOnHand === 0) return '#dc2626';
    if (item.stockOnHand <= item.reorderLevel) return '#d97706';
    return '#16a34a';
  }
}
