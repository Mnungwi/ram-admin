import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { StoreService } from '../../core/services/domain.services';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-store-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-header">
      <div>
        <h1 class="page-title">Store & Inventory</h1>
        <p class="page-subtitle">Manage materials, goods received, and issue notes</p>
      </div>
      <div class="d-flex gap-2">
        @if (auth.hasPermission('store:receive')) {
          <a routerLink="/store/receive" class="btn btn-success btn-sm">
            <i class="bi bi-box-arrow-in-down"></i> Receive Items (GRN)
          </a>
        }
        @if (auth.hasPermission('store:issue')) {
          <a routerLink="/store/issue" class="btn btn-warning btn-sm">
            <i class="bi bi-box-arrow-right"></i> Issue Items (MIN)
          </a>
        }
        @if (auth.hasPermission('store:create')) {
          <a routerLink="/store/items" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg"></i> New Item
          </a>
        }
      </div>
    </div>

    <!-- Overview Stats -->
    @if (!loading()) {
      <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
          <div class="stat-card">
            <div class="stat-icon blue"><i class="bi bi-boxes"></i></div>
            <div class="stat-body">
              <div class="stat-value">{{ overview()?.totalItems || 0 }}</div>
              <div class="stat-label">Total Items</div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
          <div class="stat-card">
            <div class="stat-icon purple"><i class="bi bi-cash-stack"></i></div>
            <div class="stat-body">
              <div class="stat-value">{{ (overview()?.totalValue || 0) | number:'1.0-0' }}</div>
              <div class="stat-label">Total Stock Value (TZS)</div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
          <div class="stat-card">
            <div class="stat-icon green"><i class="bi bi-box-arrow-in-down"></i></div>
            <div class="stat-body">
              <div class="stat-value">{{ overview()?.receiptsThisMonth || 0 }}</div>
              <div class="stat-label">GRNs This Month</div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
          <div class="stat-card">
            <div class="stat-icon orange"><i class="bi bi-box-arrow-right"></i></div>
            <div class="stat-body">
              <div class="stat-value">{{ overview()?.issuesThisMonth || 0 }}</div>
              <div class="stat-label">Issues This Month</div>
            </div>
          </div>
        </div>
      </div>
    }

    <div class="row">
      <!-- Quick Nav -->
      <div class="col-lg-4 mb-4">
        <div class="card mb-3">
          <div class="card-header"><h5 class="card-title">Quick Navigation</h5></div>
          <div class="card-body p-2">
            @for (nav of quickNav; track nav.label) {
              @if (auth.hasPermission(nav.perm)) {
                <a [routerLink]="nav.route" class="store-nav-item">
                  <div class="store-nav-icon {{ nav.color }}"><i class="bi bi-{{ nav.icon }}"></i></div>
                  <div>
                    <div class="fw-600 text-medium">{{ nav.label }}</div>
                    <div class="text-muted text-small">{{ nav.desc }}</div>
                  </div>
                  <i class="bi bi-chevron-right ml-auto text-muted"></i>
                </a>
              }
            }
          </div>
        </div>
      </div>

      <!-- Low stock alerts -->
      <div class="col-lg-8 mb-4">
        <div class="card">
          <div class="card-header">
            <h5 class="card-title">
              @if (lowStock().length > 0) {
                <i class="bi bi-exclamation-triangle-fill text-warning mr-2"></i>
              }
              Low Stock Alerts
              @if (lowStock().length > 0) {
                <span class="badge badge-pill ml-2" style="background:#d97706;color:#fff;font-size:11px">{{ lowStock().length }}</span>
              }
            </h5>
            <a routerLink="/store/items" class="btn btn-outline-primary btn-sm">View all items</a>
          </div>
          @if (loading()) {
            <div class="loading-overlay"><div class="spinner-border"></div></div>
          } @else if (lowStock().length === 0) {
            <div class="empty-state" style="padding:40px">
              <div class="empty-icon" style="font-size:36px">✅</div>
              <div class="empty-title">All items sufficiently stocked</div>
              <div class="empty-desc">No items are below their reorder level</div>
            </div>
          } @else {
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr><th>Item Code</th><th>Name</th><th>Category</th><th>Stock</th><th>Reorder At</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                  @for (item of lowStock(); track item.id) {
                    <tr>
                      <td style="font-family:monospace; font-size:12px; color:#2563eb">{{ item.itemCode }}</td>
                      <td style="font-weight:500; color:#111827">{{ item.name }}</td>
                      <td class="text-small text-muted">{{ item.category }}</td>
                      <td>
                        <span [class]="item.stockOnHand == 0 ? 'stock-empty fw-600' : 'stock-low fw-600'">
                          {{ item.stockOnHand }}
                        </span>
                        <span class="text-muted text-small ml-1">{{ item.unit }}</span>
                      </td>
                      <td class="text-small text-muted">{{ item.reorderLevel }} {{ item.unit }}</td>
                      <td>
                        @if (item.stockOnHand == 0) {
                          <span class="badge badge-overdue">Out of Stock</span>
                        } @else {
                          <span class="badge badge-pending">Low Stock</span>
                        }
                      </td>
                      <td>
                        @if (auth.hasPermission('store:receive')) {
                          <a routerLink="/store/receive" class="btn btn-success btn-sm">
                            <i class="bi bi-box-arrow-in-down"></i> Receive
                          </a>
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </div>
      </div>
    </div>

    <!-- Recent transactions -->
    <div class="row">
      <div class="col-lg-6 mb-4">
        <div class="card">
          <div class="card-header">
            <h5 class="card-title">Recent Receipts (GRN)</h5>
            <a routerLink="/store/receipts" class="btn btn-outline-primary btn-sm">View all</a>
          </div>
          <div class="card-body p-0">
            @for (r of recentReceipts(); track r.id) {
              <div class="transaction-row">
                <div class="transaction-icon green"><i class="bi bi-arrow-down-circle"></i></div>
                <div class="flex-1">
                  <div class="fw-600 text-medium">{{ r.receiptNo }}</div>
                  <div class="text-muted text-small">{{ r.deliveryNote || 'No delivery note' }} · {{ r.receivedDate | date:'dd MMM yy' }}</div>
                </div>
                <span class="badge badge-{{ r.status }}">{{ r.status }}</span>
              </div>
            }
            @if (recentReceipts().length === 0) {
              <div class="text-muted text-center py-3 text-small">No receipts yet</div>
            }
          </div>
        </div>
      </div>
      <div class="col-lg-6 mb-4">
        <div class="card">
          <div class="card-header">
            <h5 class="card-title">Recent Issues (MIN)</h5>
            <a routerLink="/store/issues" class="btn btn-outline-primary btn-sm">View all</a>
          </div>
          <div class="card-body p-0">
            @for (i of recentIssues(); track i.id) {
              <div class="transaction-row">
                <div class="transaction-icon orange"><i class="bi bi-arrow-up-circle"></i></div>
                <div class="flex-1">
                  <div class="fw-600 text-medium">{{ i.issueNo }}</div>
                  <div class="text-muted text-small">{{ i.issuedToName || 'Unassigned' }} · {{ i.issueDate | date:'dd MMM yy' }}</div>
                </div>
                <span class="badge badge-{{ i.status === 'issued' ? 'completed' : i.status }}">{{ i.status }}</span>
              </div>
            }
            @if (recentIssues().length === 0) {
              <div class="text-muted text-center py-3 text-small">No issues yet</div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .store-nav-item {
      display: flex; align-items: center; gap: 12px;
      padding: 10px 8px; border-radius: 8px; cursor: pointer;
      transition: background .15s; text-decoration: none;
      &:hover { background: #f9fafb; }
    }
    .store-nav-icon {
      width: 38px; height: 38px; border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; flex-shrink: 0;
      &.blue   { background: #eff6ff; color: #2563eb; }
      &.green  { background: #f0fdf4; color: #16a34a; }
      &.orange { background: #fff7ed; color: #f97316; }
      &.purple { background: #faf5ff; color: #9333ea; }
      &.teal   { background: #f0fdfa; color: #0d9488; }
    }
    .transaction-row {
      display: flex; align-items: center; gap: 12px;
      padding: 12px 16px; border-bottom: 1px solid #f3f4f6;
      &:last-child { border-bottom: none; }
    }
    .transaction-icon {
      width: 34px; height: 34px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 16px; flex-shrink: 0;
      &.green  { background: #dcfce7; color: #16a34a; }
      &.orange { background: #fed7aa; color: #c2410c; }
    }
    .flex-1 { flex: 1; min-width: 0; }
  `]
})
export class StoreDashboardComponent implements OnInit {
  overview = signal<any>(null);
  lowStock = signal<any[]>([]);
  recentReceipts = signal<any[]>([]);
  recentIssues = signal<any[]>([]);
  loading = signal(true);

  quickNav = [
    { label: 'All Items',       desc: 'View and manage stock items',    route: '/store/items',    icon: 'boxes',              color: 'blue',   perm: 'store:view' },
    { label: 'Receive Items',   desc: 'Create Goods Received Note',     route: '/store/receive',  icon: 'box-arrow-in-down',  color: 'green',  perm: 'store:receive' },
    { label: 'All GRNs',        desc: 'View all goods received notes',  route: '/store/receipts', icon: 'receipt',            color: 'teal',   perm: 'store:view' },
    { label: 'Issue Items',     desc: 'Create Material Issue Note',     route: '/store/issue',    icon: 'box-arrow-right',    color: 'orange', perm: 'store:issue' },
    { label: 'All MINs',        desc: 'View all material issue notes',  route: '/store/issues',   icon: 'list-check',         color: 'purple', perm: 'store:view' },
  ];

  constructor(private svc: StoreService, public auth: AuthService) {}

  ngOnInit(): void {
    this.svc.getOverview().subscribe({
      next: (res: any) => {
        const d = res.data || {};
        this.overview.set(d);
        this.lowStock.set(d.lowStockItems || []);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
    this.svc.getReceipts({ limit: 5 }).subscribe({ next: (r: any) => this.recentReceipts.set(r.data || []) });
    this.svc.getIssues({ limit: 5 }).subscribe({ next: (r: any) => this.recentIssues.set(r.data || []) });
  }
}
