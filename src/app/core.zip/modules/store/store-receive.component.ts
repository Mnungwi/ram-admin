import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormArray, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { StoreService } from '../../core/services/domain.services';

@Component({
  selector: 'app-store-receive',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="page-header">
      <div>
        <h1 class="page-title">Receive Items — GRN</h1>
        <p class="page-subtitle">Create a Goods Received Note to add items to stock</p>
      </div>
      <a routerLink="/store" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Back</a>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <form [formGroup]="form" (ngSubmit)="onSubmit()">
          @if (error()) {
            <div class="alert alert-danger mb-3">{{ error() }}</div>
          }

          <!-- GRN Header -->
          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">Receipt Details</h5></div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Received Date *</label>
                  <input type="date" class="form-control" formControlName="receivedDate">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Delivery Note No.</label>
                  <input class="form-control" formControlName="deliveryNote" placeholder="DN-2026-055">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Invoice Reference</label>
                  <input class="form-control" formControlName="invoiceRef" placeholder="INV-2026-030">
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">Notes</label>
                <textarea class="form-control" formControlName="notes" rows="2"
                          placeholder="Any notes about this delivery..."></textarea>
              </div>
            </div>
          </div>

          <!-- Line Items -->
          <div class="card mb-3">
            <div class="card-header">
              <h5 class="card-title">Items Received</h5>
              <button type="button" class="btn btn-outline-primary btn-sm" (click)="addLine()">
                <i class="bi bi-plus-lg"></i> Add Item
              </button>
            </div>
            <div class="card-body">
              @if (linesArray.length === 0) {
                <div class="text-muted text-center py-3">
                  <i class="bi bi-box mb-2" style="font-size:28px;display:block;opacity:.3"></i>
                  Click "Add Item" to add items to this receipt
                </div>
              }

              @for (line of linesArray.controls; track $index) {
                <div class="grn-line" [formGroup]="getLine($index)">
                  <div class="grn-line-num">{{ $index + 1 }}</div>
                  <div class="row flex-1" style="flex:1">
                    <div class="col-md-4 mb-2">
                      <label class="form-label-sm">Item *</label>
                      <select class="form-control form-control-sm" formControlName="storeItemId" (change)="onItemSelect($index)">
                        <option value="">— Select Item —</option>
                        @for (item of storeItems(); track item.id) {
                          <option [value]="item.id">{{ item.itemCode }} – {{ item.name }}</option>
                        }
                      </select>
                    </div>
                    <div class="col-md-2 mb-2">
                      <label class="form-label-sm">Qty Ordered</label>
                      <input type="number" class="form-control form-control-sm" formControlName="qtyOrdered" min="0">
                    </div>
                    <div class="col-md-2 mb-2">
                      <label class="form-label-sm">Qty Received *</label>
                      <input type="number" class="form-control form-control-sm" formControlName="qtyReceived" min="0">
                    </div>
                    <div class="col-md-2 mb-2">
                      <label class="form-label-sm">Qty Rejected</label>
                      <input type="number" class="form-control form-control-sm" formControlName="qtyRejected" min="0">
                    </div>
                    <div class="col-md-2 mb-2">
                      <label class="form-label-sm">Unit Cost (TZS)</label>
                      <input type="number" class="form-control form-control-sm" formControlName="unitCost" min="0">
                    </div>
                  </div>
                  <button type="button" class="action-btn danger mt-3" (click)="removeLine($index)">
                    <i class="bi bi-trash"></i>
                  </button>
                </div>
              }

              @if (linesArray.length > 0) {
                <div class="mt-3 p-3 bg-light rounded">
                  <div class="d-flex justify-content-between">
                    <span class="fw-600">Total Lines: {{ linesArray.length }}</span>
                    <span class="fw-600">Total Value: {{ calcTotal() | number:'1.0-0' }} TZS</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="d-flex gap-2 justify-content-end">
            <a routerLink="/store" class="btn btn-outline-secondary">Cancel</a>
            <button type="submit" class="btn btn-success" [disabled]="saving() || linesArray.length === 0">
              @if (saving()) { <span class="spinner-border spinner-border-sm mr-2"></span> }
              <i class="bi bi-box-arrow-in-down"></i> Create GRN & Update Stock
            </button>
          </div>
        </form>
      </div>

      <!-- Info panel -->
      <div class="col-lg-4">
        <div class="card" style="position:sticky;top:80px">
          <div class="card-header"><h5 class="card-title">How GRN Works</h5></div>
          <div class="card-body">
            <div class="timeline">
              <div class="timeline-item">
                <div class="timeline-title">Create GRN</div>
                <div class="timeline-body">Enter delivery details and all items received</div>
              </div>
              <div class="timeline-item">
                <div class="timeline-title">Stock Updated</div>
                <div class="timeline-body">Stock on hand increases by qty received minus qty rejected</div>
              </div>
              <div class="timeline-item">
                <div class="timeline-title">Ledger Entry</div>
                <div class="timeline-body">Each line creates an immutable "receipt" entry in the stock ledger</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .grn-line {
      display: flex; align-items: flex-start; gap: 10px;
      padding: 12px; background: #f9fafb; border-radius: 8px;
      border: 1px solid #e5e7eb; margin-bottom: 8px;
    }
    .grn-line-num {
      width: 24px; height: 24px; background: #2563eb; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 700; color: #fff; flex-shrink: 0; margin-top: 22px;
    }
    .form-label-sm { font-size: 11px; font-weight: 600; color: #6b7280; margin-bottom: 3px; }
  `]
})
export class StoreReceiveComponent implements OnInit {
  form = this.fb.group({
    receivedDate: [new Date().toISOString().split('T')[0], Validators.required],
    deliveryNote: [''],
    invoiceRef:   [''],
    notes:        [''],
    lines:        this.fb.array([])
  });

  storeItems = signal<any[]>([]);
  saving = signal(false);
  error = signal('');

  get linesArray() { return this.form.get('lines') as FormArray; }
  getLine(i: number): FormGroup { return this.linesArray.at(i) as FormGroup; }

  constructor(private fb: FormBuilder, private svc: StoreService, private router: Router) {}

  ngOnInit(): void {
    this.svc.getItems({ limit: 200 }).subscribe({ next: (r: any) => this.storeItems.set(r.data || []) });
    this.addLine();
  }

  addLine(): void {
    this.linesArray.push(this.fb.group({
      storeItemId:  ['', Validators.required],
      qtyOrdered:   [0],
      qtyReceived:  [0, [Validators.required, Validators.min(0.001)]],
      qtyRejected:  [0],
      unitCost:     [0],
    }));
  }

  removeLine(i: number): void { this.linesArray.removeAt(i); }

  onItemSelect(i: number): void {
    const id = this.getLine(i).get('storeItemId')?.value;
    const item = this.storeItems().find(s => s.id === id);
    if (item) this.getLine(i).patchValue({ unitCost: item.unitCost });
  }

  calcTotal(): number {
    return this.linesArray.controls.reduce((sum, ctrl) => {
      return sum + (ctrl.get('qtyReceived')?.value || 0) * (ctrl.get('unitCost')?.value || 0);
    }, 0);
  }

  onSubmit(): void {
    if (this.form.invalid || this.linesArray.length === 0) return;
    this.saving.set(true);
    this.error.set('');
    this.svc.createReceipt(this.form.value).subscribe({
      next: () => this.router.navigate(['/store/receipts']),
      error: err => { this.saving.set(false); this.error.set(err.error?.message || 'Failed to create GRN'); }
    });
  }
}
