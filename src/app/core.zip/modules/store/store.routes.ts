import { Routes } from '@angular/router';

export const storeRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./store-dashboard.component').then(m => m.StoreDashboardComponent)
  },
  {
    path: 'items',
    loadComponent: () => import('./store-items.component').then(m => m.StoreItemsComponent)
  },
  {
    path: 'receive',
    loadComponent: () => import('./store-receive.component').then(m => m.StoreReceiveComponent)
  },
  {
    path: 'receipts',
    loadComponent: () => import('./store-receipts.component').then(m => m.StoreReceiptsComponent)
  },
  {
    path: 'issue',
    loadComponent: () => import('./store-issue.component').then(m => m.StoreIssueComponent)
  },
  {
    path: 'issues',
    loadComponent: () => import('./store-issues.component').then(m => m.StoreIssuesComponent)
  },
  {
    path: 'items/:id/ledger',
    loadComponent: () => import('./store-ledger.component').then(m => m.StoreLedgerComponent)
  }
];
