import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page-header">
      <div><h1 class="page-title">Settings</h1><p class="page-subtitle">Manage your account and preferences</p></div>
    </div>

    <div class="row">
      <div class="col-lg-3 mb-4">
        <div class="card">
          <div class="card-body text-center">
            <div class="settings-avatar">{{ auth.userInitials() }}</div>
            <div class="fw-600 mt-2">{{ auth.userFullName() }}</div>
            <div class="text-muted text-small">{{ auth.currentUser()?.jobTitle }}</div>
            <div class="text-muted text-small">{{ auth.currentUser()?.email }}</div>
            <div class="mt-2">
              @for (r of (auth.currentUser()?.roles || []); track r.id) {
                <span class="role-badge" [style.background]="r.color + '22'" [style.color]="r.color">{{ r.name }}</span>
              }
            </div>
          </div>
        </div>

        <div class="card mt-3">
          <div class="list-group list-group-flush" style="border-radius:8px">
            @for (tab of tabs; track tab.key) {
              <button class="list-group-item list-group-item-action d-flex align-items-center gap-2"
                      [class.active]="activeTab() === tab.key"
                      (click)="activeTab.set(tab.key)"
                      style="font-size:13px;border:none">
                <i class="bi bi-{{ tab.icon }}"></i> {{ tab.label }}
              </button>
            }
          </div>
        </div>
      </div>

      <div class="col-lg-9">
        @switch (activeTab()) {
          @case ('profile') {
            <div class="card">
              <div class="card-header"><h5 class="card-title">Profile Information</h5></div>
              <div class="card-body">
                @if (success()) { <div class="alert alert-success text-small">{{ success() }}</div> }
                @if (error()) { <div class="alert alert-danger text-small">{{ error() }}</div> }
                <form [formGroup]="profileForm" (ngSubmit)="saveProfile()">
                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label class="form-label">First Name</label>
                      <input class="form-control" formControlName="firstName">
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label">Last Name</label>
                      <input class="form-control" formControlName="lastName">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 mb-3">
                      <label class="form-label">Job Title</label>
                      <input class="form-control" formControlName="jobTitle">
                    </div>
                    <div class="col-md-6 mb-3">
                      <label class="form-label">Department</label>
                      <input class="form-control" formControlName="department">
                    </div>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input class="form-control" formControlName="phone">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input class="form-control" formControlName="email" readonly style="background:#f9fafb">
                  </div>
                  <button type="submit" class="btn btn-primary" [disabled]="saving()">
                    @if (saving()) { <span class="spinner-border spinner-border-sm mr-2"></span> }
                    Save Changes
                  </button>
                </form>
              </div>
            </div>
          }

          @case ('password') {
            <div class="card">
              <div class="card-header"><h5 class="card-title">Change Password</h5></div>
              <div class="card-body" style="max-width:400px">
                @if (pwSuccess()) { <div class="alert alert-success text-small">{{ pwSuccess() }}</div> }
                @if (pwError()) { <div class="alert alert-danger text-small">{{ pwError() }}</div> }
                <form [formGroup]="pwForm" (ngSubmit)="changePassword()">
                  <div class="mb-3">
                    <label class="form-label">Current Password</label>
                    <input type="password" class="form-control" formControlName="currentPassword">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <input type="password" class="form-control" formControlName="newPassword">
                  </div>
                  <div class="mb-4">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" class="form-control" formControlName="confirmPassword">
                  </div>
                  <button type="submit" class="btn btn-primary" [disabled]="saving()">Update Password</button>
                </form>
              </div>
            </div>
          }

          @case ('permissions') {
            <div class="card">
              <div class="card-header"><h5 class="card-title">My Permissions</h5></div>
              <div class="card-body">
                <p class="text-muted text-small mb-3">These are your effective permissions based on your assigned roles.</p>
                @for (group of permissionGroups(); track group.name) {
                  <div class="mb-4">
                    <div class="fw-600 text-small mb-2" style="text-transform:uppercase;letter-spacing:.5px;color:#9ca3af">{{ group.name }}</div>
                    <div class="d-flex flex-wrap gap-1">
                      @for (p of group.permissions; track p) {
                        <span class="perm-badge">{{ p }}</span>
                      }
                    </div>
                  </div>
                }
              </div>
            </div>
          }
        }
      </div>
    </div>
  `,
  styles: [`
    .settings-avatar {
      width:72px;height:72px;border-radius:50%;background:#1e3a5f;color:#fff;
      display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;margin:0 auto 8px;
    }
    .role-badge { display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:500;margin:2px; }
    .perm-badge {
      display:inline-block;padding:2px 10px;border-radius:10px;
      background:#eff6ff;color:#2563eb;font-size:11px;font-family:monospace;
    }
  `]
})
export class SettingsComponent implements OnInit {
  activeTab = signal('profile');
  saving = signal(false);
  success = signal('');
  error = signal('');
  pwSuccess = signal('');
  pwError = signal('');

  tabs = [
    { key: 'profile',     label: 'Profile',     icon: 'person' },
    { key: 'password',    label: 'Password',     icon: 'lock' },
    { key: 'permissions', label: 'Permissions',  icon: 'shield-check' },
  ];

  profileForm = this.fb.group({
    firstName:  ['', Validators.required],
    lastName:   ['', Validators.required],
    email:      [''],
    phone:      [''],
    jobTitle:   [''],
    department: ['']
  });

  pwForm = this.fb.group({
    currentPassword: ['', Validators.required],
    newPassword:     ['', [Validators.required, Validators.minLength(8)]],
    confirmPassword: ['', Validators.required]
  });

  permissionGroups = signal<any[]>([]);

  constructor(public auth: AuthService, private fb: FormBuilder, private http: HttpClient) {}

  ngOnInit(): void {
    const user = this.auth.currentUser();
    if (user) this.profileForm.patchValue(user);

    // Group permissions
    const perms = this.auth.permissions();
    const groups: Record<string, string[]> = {};
    perms.forEach(p => {
      const [resource] = p.split(':');
      const group = resource.charAt(0).toUpperCase() + resource.slice(1).replace(/_/g, ' ');
      if (!groups[group]) groups[group] = [];
      groups[group].push(p);
    });
    this.permissionGroups.set(Object.entries(groups).map(([name, permissions]) => ({ name, permissions })));
  }

  saveProfile(): void {
    this.saving.set(true);
    this.success.set(''); this.error.set('');
    this.http.put(`${environment.apiUrl}/auth/me`, this.profileForm.value).subscribe({
      next: () => { this.saving.set(false); this.success.set('Profile updated successfully'); this.auth.getProfile().subscribe(); },
      error: err => { this.saving.set(false); this.error.set(err.error?.message || 'Failed to update profile'); }
    });
  }

  changePassword(): void {
    const { currentPassword, newPassword, confirmPassword } = this.pwForm.value as any;
    if (newPassword !== confirmPassword) { this.pwError.set('Passwords do not match'); return; }
    this.saving.set(true);
    this.pwSuccess.set(''); this.pwError.set('');
    this.http.post(`${environment.apiUrl}/auth/me/change-password`, { currentPassword, newPassword }).subscribe({
      next: () => { this.saving.set(false); this.pwSuccess.set('Password changed successfully'); this.pwForm.reset(); },
      error: err => { this.saving.set(false); this.pwError.set(err.error?.message || 'Failed to change password'); }
    });
  }
}
