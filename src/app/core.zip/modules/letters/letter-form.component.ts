import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule, FormArray, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { LetterService } from '../../core/services/domain.services';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-letter-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="page-header">
      <div>
        <h1 class="page-title">{{ isEdit ? 'Edit Letter' : 'Compose Letter' }}</h1>
        <p class="page-subtitle">{{ isEdit ? 'Update letter details' : 'Create a new letter or correspondence' }}</p>
      </div>
      <a routerLink="/letters" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back
      </a>
    </div>

    <div class="row">
      <!-- Form -->
      <div class="col-lg-8">
        <form [formGroup]="form" (ngSubmit)="onSave('draft')">
          @if (error()) {
            <div class="alert alert-danger mb-3">{{ error() }}</div>
          }

          <!-- Header Info -->
          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">Letter Details</h5></div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Type <span class="text-danger">*</span></label>
                  <select class="form-control" formControlName="type">
                    <option value="outgoing">Outgoing</option>
                    <option value="incoming">Incoming</option>
                    <option value="internal">Internal</option>
                    <option value="memo">Memo</option>
                  </select>
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Priority</label>
                  <select class="form-control" formControlName="priority">
                    <option value="low">Low</option>
                    <option value="normal">Normal</option>
                    <option value="high">High</option>
                    <option value="urgent">🔴 Urgent</option>
                  </select>
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Letter Date <span class="text-danger">*</span></label>
                  <input type="date" class="form-control" formControlName="letterDate">
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label">Subject <span class="text-danger">*</span></label>
                <input class="form-control" formControlName="subject"
                       placeholder="e.g. Re: Site Inspection Schedule – June 2026"
                       [class.is-invalid]="f['subject'].touched && f['subject'].invalid">
                @if (f['subject'].touched && f['subject'].invalid) {
                  <div class="invalid-feedback">Subject is required</div>
                }
              </div>

              <div class="mb-3">
                <label class="form-label">Reference No.</label>
                <input class="form-control" formControlName="referenceNo" placeholder="e.g. ZAE-2026-001">
              </div>
            </div>
          </div>

          <!-- From -->
          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">From (Sender)</h5></div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Name</label>
                  <input class="form-control" formControlName="fromName" placeholder="Full name">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Title / Position</label>
                  <input class="form-control" formControlName="fromTitle" placeholder="e.g. Project Manager">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Organisation</label>
                  <input class="form-control" formControlName="fromOrg" placeholder="e.g. Farida Projects Ltd">
                </div>
              </div>
            </div>
          </div>

          <!-- To -->
          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">To (Primary Recipient) <span class="text-danger">*</span></h5></div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Name <span class="text-danger">*</span></label>
                  <input class="form-control" formControlName="toName" placeholder="Recipient name"
                         [class.is-invalid]="f['toName'].touched && f['toName'].invalid">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Title / Position</label>
                  <input class="form-control" formControlName="toTitle" placeholder="e.g. Site Engineer">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Email</label>
                  <input type="email" class="form-control" formControlName="toEmail" placeholder="recipient@example.com">
                </div>
              </div>
              <div class="mb-2">
                <label class="form-label">Organisation</label>
                <input class="form-control" formControlName="toOrg" placeholder="Organisation name">
              </div>
            </div>
          </div>

          <!-- CC Recipients -->
          <div class="card mb-3">
            <div class="card-header">
              <h5 class="card-title">CC Recipients</h5>
              <button type="button" class="btn btn-outline-primary btn-sm" (click)="addCc()">
                <i class="bi bi-plus-lg"></i> Add CC
              </button>
            </div>
            <div class="card-body">
              @if (ccArray.length === 0) {
                <div class="text-muted text-small text-center py-2">No CC recipients added</div>
              }
              @for (cc of ccArray.controls; track $index) {
                <div class="cc-row" [formGroup]="getCcGroup($index)">
                  <div class="cc-index">{{ $index + 1 }}</div>
                  <div class="row flex-1" style="flex:1">
                    <div class="col-md-4 mb-2">
                      <input class="form-control form-control-sm" formControlName="name" placeholder="Full name">
                    </div>
                    <div class="col-md-4 mb-2">
                      <input class="form-control form-control-sm" formControlName="title" placeholder="Title / Position">
                    </div>
                    <div class="col-md-4 mb-2">
                      <input class="form-control form-control-sm" formControlName="email" placeholder="Email address">
                    </div>
                  </div>
                  <button type="button" class="action-btn danger" (click)="removeCc($index)">
                    <i class="bi bi-trash"></i>
                  </button>
                </div>
              }
            </div>
          </div>

          <!-- Body -->
          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">Letter Body <span class="text-danger">*</span></h5></div>
            <div class="card-body">
              <textarea class="form-control" formControlName="body" rows="12"
                        placeholder="Dear Sir/Madam,&#10;&#10;With reference to the above subject...&#10;&#10;Yours faithfully,"
                        style="font-family: 'Times New Roman', serif; font-size: 14px; line-height: 1.8"
                        [class.is-invalid]="f['body'].touched && f['body'].invalid"></textarea>
              @if (f['body'].touched && f['body'].invalid) {
                <div class="invalid-feedback">Letter body is required</div>
              }
              <div class="text-muted text-small mt-1">
                {{ form.get('body')?.value?.length || 0 }} characters
              </div>
            </div>
          </div>

          <!-- Notes -->
          <div class="card mb-3">
            <div class="card-header"><h5 class="card-title">Internal Notes</h5></div>
            <div class="card-body">
              <textarea class="form-control" formControlName="notes" rows="2"
                        placeholder="Notes visible only to staff (not printed on letter)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div class="d-flex gap-2 justify-content-end">
            <a routerLink="/letters" class="btn btn-outline-secondary">Cancel</a>
            <button type="button" class="btn btn-outline-primary" [disabled]="saving()" (click)="onSave('draft')">
              <i class="bi bi-save"></i> Save as Draft
            </button>
            @if (auth.hasPermission('letter:send')) {
              <button type="button" class="btn btn-warning" [disabled]="saving()" (click)="onSave('submit')">
                <i class="bi bi-send"></i> Save & Submit
              </button>
            }
          </div>
        </form>
      </div>

      <!-- Sidebar -->
      <div class="col-lg-4">
        <!-- Live Preview Card -->
        <div class="card mb-3" style="position: sticky; top: 80px">
          <div class="card-header">
            <h5 class="card-title"><i class="bi bi-eye mr-2"></i>Preview</h5>
            @if (savedId()) {
              <a [href]="previewUrl()" target="_blank" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-box-arrow-up-right"></i> Full Preview
              </a>
            }
          </div>
          <div class="card-body" style="font-family: 'Times New Roman', serif; font-size: 12px; line-height: 1.6; color:#222">
            <!-- Mini letterhead preview -->
            <div style="border-bottom: 2px solid #1e3a5f; padding-bottom: 8px; margin-bottom: 12px">
              <div style="font-size:14px; font-weight:700; color:#1e3a5f">🏗 FARIDA PROJECTS</div>
              <div style="font-size:10px; color:#888">Excellence in Construction Management</div>
            </div>
            <div style="display:flex; justify-content:space-between; margin-bottom:10px">
              <div style="font-size:10px; color:#666">Ref: <strong>LTR-{{ currentYear }}-XXXX</strong></div>
              <div class="priority-preview priority-{{ f['priority'].value }}">
                {{ (f['priority'].value || 'normal').toUpperCase() }}
              </div>
            </div>
            <div style="margin-bottom:10px">
              <div style="font-size:10px; color:#888">TO</div>
              <div style="font-weight:600">{{ f['toName'].value || 'Recipient Name' }}</div>
              <div style="color:#666">{{ f['toTitle'].value }}</div>
              <div style="color:#666">{{ f['toOrg'].value }}</div>
            </div>
            <div style="margin-bottom:10px">
              <div style="font-size:10px; color:#888">SUBJECT</div>
              <div style="font-weight:600; text-decoration:underline">{{ f['subject'].value || 'Letter Subject' }}</div>
            </div>
            <div style="white-space:pre-wrap; max-height:200px; overflow:hidden; color:#444; font-size:11px">{{ (f['body'].value || 'Letter body will appear here...') | slice:0:400 }}{{ (f['body'].value?.length || 0) > 400 ? '...' : '' }}</div>
            @if (ccArray.length > 0) {
              <div style="margin-top:12px; border-top:1px solid #eee; padding-top:8px; font-size:10px; color:#888">
                <strong>CC:</strong>
                @for (cc of ccArray.controls; track $index) {
                  <div style="margin-left:8px">{{ getCcGroup($index).get('name')?.value }}</div>
                }
              </div>
            }
          </div>
        </div>

        <!-- Tips -->
        <div class="card">
          <div class="card-header"><h5 class="card-title">Writing Tips</h5></div>
          <div class="card-body">
            @for (tip of tips; track tip) {
              <div class="d-flex gap-2 mb-2">
                <i class="bi bi-check-circle-fill text-success" style="font-size:14px; flex-shrink:0; margin-top:2px"></i>
                <span style="font-size:12.5px; color:#6b7280">{{ tip }}</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .cc-row {
      display: flex; align-items: flex-start; gap: 10px;
      padding: 10px; background: #f9fafb; border-radius: 8px;
      border: 1px solid #e5e7eb; margin-bottom: 8px;
    }
    .cc-index {
      width: 24px; height: 24px; background: #e5e7eb; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 600; color: #6b7280; flex-shrink: 0; margin-top: 4px;
    }
    .priority-preview {
      padding: 2px 8px; border-radius: 10px; font-size: 9px; font-weight: 700;
      &.priority-urgent { background: #fee2e2; color: #991b1b; }
      &.priority-high   { background: #fff7ed; color: #9a3412; }
      &.priority-normal { background: #eff6ff; color: #1e40af; }
      &.priority-low    { background: #f3f4f6; color: #6b7280; }
    }
  `]
})
export class LetterFormComponent implements OnInit {
  form = this.fb.group({
    type:        ['outgoing'],
    priority:    ['normal'],
    letterDate:  [new Date().toISOString().split('T')[0], Validators.required],
    subject:     ['', Validators.required],
    referenceNo: [''],
    fromName:    [''],
    fromTitle:   [''],
    fromOrg:     ['Farida Projects Ltd'],
    toName:      ['', Validators.required],
    toTitle:     [''],
    toOrg:       [''],
    toEmail:     ['', Validators.email],
    body:        ['', Validators.required],
    notes:       [''],
    ccRecipients: this.fb.array([])
  });

  saving = signal(false);
  error = signal('');
  isEdit = false;
  savedId = signal('');
  letterId = '';
  currentYear = new Date().getFullYear();

  tips = [
    'Start with a clear reference to the subject',
    'Keep paragraphs short and focused',
    'Use formal language: "We write to inform..." not "I wanted to say..."',
    'Always include the letter date and reference number',
    'Add CC recipients for stakeholders who need to be informed',
  ];

  get f() { return this.form.controls; }
  get ccArray() { return this.form.get('ccRecipients') as FormArray; }

  getCcGroup(index: number): FormGroup {
    return this.ccArray.at(index) as FormGroup;
  }

  previewUrl(): string {
    return this.savedId() ? `http://localhost:3000/api/letters/${this.savedId()}/preview` : '';
  }

  constructor(
    private fb: FormBuilder,
    private svc: LetterService,
    private router: Router,
    private route: ActivatedRoute,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    this.letterId = this.route.snapshot.paramMap.get('id') || '';
    this.isEdit = !!this.letterId && this.route.snapshot.url.some(s => s.path === 'edit');

    // Auto-fill from current user
    const user = this.auth.currentUser();
    if (user) {
      this.form.patchValue({
        fromName:  `${user.firstName} ${user.lastName}`,
        fromTitle: user.jobTitle || '',
        fromOrg:   'Farida Projects Ltd'
      });
    }

    if (this.isEdit && this.letterId) {
      this.svc.getOne(this.letterId).subscribe({
        next: (res: any) => {
          const l = res.data?.letter || res.data;
          this.form.patchValue(l);
          this.savedId.set(this.letterId);
          // Rebuild CC
          this.ccArray.clear();
          (l.ccRecipients || []).forEach((cc: any) => this.ccArray.push(this.fb.group(cc)));
        }
      });
    }
  }

  addCc(): void {
    this.ccArray.push(this.fb.group({ name: [''], title: [''], email: [''] }));
  }

  removeCc(i: number): void {
    this.ccArray.removeAt(i);
  }

  onSave(action: 'draft' | 'submit'): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    this.error.set('');

    const data = this.form.value;

    const obs = this.isEdit
      ? this.svc.update(this.letterId, data)
      : this.svc.create(data);

    obs.subscribe({
      next: (res: any) => {
        const id = res.data?.letter?.id || this.letterId;
        this.savedId.set(id);

        if (action === 'submit') {
          this.svc.submit(id).subscribe({
            next: () => this.router.navigate(['/letters', id]),
            error: () => this.router.navigate(['/letters', id])
          });
        } else {
          this.saving.set(false);
          if (!this.isEdit) {
            this.router.navigate(['/letters', id]);
          }
        }
      },
      error: err => {
        this.saving.set(false);
        this.error.set(err.error?.message || 'Failed to save letter');
      }
    });
  }
}
