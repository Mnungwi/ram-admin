import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';

// ─── Projects Service ────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ProjectService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll(params?: any)            { return this.get<any>('/projects', params); }
  getOne(id: string)              { return this.get<any>(`/projects/${id}`); }
  getOverview(id: string)         { return this.get<any>(`/projects/${id}/overview`); }
  create(data: any)               { return this.post<any>('/projects', data); }
  update(id: string, data: any)   { return this.put<any>(`/projects/${id}`, data); }
  deleteProject(id: string)       { return this.remove<any>(`/projects/${id}`); }

  getActivities(pid: string, params?: any) { return this.get<any>(`/projects/${pid}/activities`, params); }
  createActivity(pid: string, data: any)   { return this.post<any>(`/projects/${pid}/activities`, data); }
  updateActivity(pid: string, aid: string, data: any) { return this.put<any>(`/projects/${pid}/activities/${aid}`, data); }
  deleteActivity(pid: string, aid: string) { return this.remove<any>(`/projects/${pid}/activities/${aid}`); }

  getTeam(pid: string)                     { return this.get<any>(`/projects/${pid}/team`); }
  addTeamMember(pid: string, data: any)    { return this.post<any>(`/projects/${pid}/team`, data); }
  removeTeamMember(pid: string, uid: string) { return this.remove<any>(`/projects/${pid}/team/${uid}`); }

  getReports(pid: string, params?: any)    { return this.get<any>(`/projects/${pid}/reports`, params); }
  createReport(pid: string, data: any)     { return this.post<any>(`/projects/${pid}/reports`, data); }
  updateReport(pid: string, rid: string, data: any) { return this.put<any>(`/projects/${pid}/reports/${rid}`, data); }
  approveReport(pid: string, rid: string)  { return this.post<any>(`/projects/${pid}/reports/${rid}/approve`, {}); }

  getDocuments(pid: string)                { return this.get<any>(`/projects/${pid}/documents`); }
  uploadDocument(pid: string, fd: FormData){ return this.upload<any>(`/projects/${pid}/documents`, fd); }

  getContracts(pid: string)                { return this.get<any>(`/projects/${pid}/contracts`); }
  createContract(pid: string, data: any)   { return this.post<any>(`/projects/${pid}/contracts`, data); }
  updateContract(pid: string, cid: string, data: any) { return this.put<any>(`/projects/${pid}/contracts/${cid}`, data); }
  getPurchaseOrders(pid: string)           { return this.get<any>(`/projects/${pid}/purchase-orders`); }
  createPurchaseOrder(pid: string, data: any) { return this.post<any>(`/projects/${pid}/purchase-orders`, data); }
}

// ─── Finance Service ─────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class FinanceService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getOverview(pid: string)         { return this.get<any>(`/projects/${pid}/finance`); }
  getBudget(pid: string)           { return this.get<any>(`/projects/${pid}/finance/budget`); }
  upsertBudget(pid: string, data: any) { return this.post<any>(`/projects/${pid}/finance/budget`, data); }

  getInvoices(pid: string, params?: any) { return this.get<any>(`/projects/${pid}/finance/invoices`, params); }
  createInvoice(pid: string, data: any)  { return this.post<any>(`/projects/${pid}/finance/invoices`, data); }
  approveInvoice(pid: string, iid: string) { return this.post<any>(`/projects/${pid}/finance/invoices/${iid}/approve`, {}); }

  getPayments(pid: string, params?: any) { return this.get<any>(`/projects/${pid}/finance/payments`, params); }
  createPayment(pid: string, data: any)  { return this.post<any>(`/projects/${pid}/finance/payments`, data); }
  approvePayment(pid: string, pid2: string) { return this.post<any>(`/projects/${pid}/finance/payments/${pid2}/approve`, {}); }

  getExpenses(pid: string, params?: any) { return this.get<any>(`/projects/${pid}/finance/expenses`, params); }
  createExpense(pid: string, data: any)  { return this.post<any>(`/projects/${pid}/finance/expenses`, data); }
}

// ─── Letter Service ───────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class LetterService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll(params?: any)              { return this.get<any>('/letters', params); }
  getInbox(params?: any)            { return this.get<any>('/letters/inbox', params); }
  getOne(id: string)                { return this.get<any>(`/letters/${id}`); }
  create(data: any)                 { return this.post<any>('/letters', data); }
  update(id: string, data: any)     { return this.put<any>(`/letters/${id}`, data); }
  deleteLetter(id: string)          { return this.remove<any>(`/letters/${id}`); }
  submit(id: string)                { return this.post<any>(`/letters/${id}/submit`, {}); }
  approve(id: string)               { return this.post<any>(`/letters/${id}/approve`, {}); }
  send(id: string, data?: any)      { return this.post<any>(`/letters/${id}/send`, data || {}); }
  archive(id: string)               { return this.post<any>(`/letters/${id}/archive`, {}); }
  getStats(pid?: string)            {
    const path = pid ? `/projects/${pid}/letters/stats` : '/letters/stats';
    return this.get<any>(path);
  }

  getPreviewUrl(id: string): string {
    return `${this.base}/letters/${id}/preview`;
  }

  downloadPdf(id: string): Observable<Blob> {
    return this.getBlob(`/letters/${id}/download`);
  }
}

// ─── Store Service ────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class StoreService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getOverview(pid?: string) {
    const p = pid ? `/projects/${pid}/store/overview` : '/store/overview';
    return this.get<any>(p);
  }

  getItems(params?: any)              { return this.get<any>('/store', params); }
  getItem(id: string)                 { return this.get<any>(`/store/items/${id}`); }
  createItem(data: any)               { return this.post<any>('/store', data); }
  updateItem(id: string, data: any)   { return this.put<any>(`/store/items/${id}`, data); }
  deleteItem(id: string)              { return this.remove<any>(`/store/items/${id}`); }
  adjustStock(id: string, data: any)  { return this.post<any>(`/store/items/${id}/adjust`, data); }
  getLedger(id: string, params?: any) { return this.get<any>(`/store/items/${id}/ledger`, params); }

  getReceipts(params?: any)           { return this.get<any>('/store/receipts', params); }
  getReceipt(id: string)              { return this.get<any>(`/store/receipts/${id}`); }
  createReceipt(data: any)            { return this.post<any>('/store/receipts', data); }

  getIssues(params?: any)             { return this.get<any>('/store/issues', params); }
  getIssue(id: string)                { return this.get<any>(`/store/issues/${id}`); }
  createIssue(data: any)              { return this.post<any>('/store/issues', data); }
  approveIssue(id: string)            { return this.post<any>(`/store/issues/${id}/approve`, {}); }
  dispatchIssue(id: string, data: any){ return this.post<any>(`/store/issues/${id}/dispatch`, data); }
  returnIssue(id: string, data: any)  { return this.post<any>(`/store/issues/${id}/return`, data); }
}

// ─── User Service ─────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class UserService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll(params?: any)                { return this.get<any>('/users', params); }
  getOne(id: string)                  { return this.get<any>(`/users/${id}`); }
  create(data: any)                   { return this.post<any>('/users', data); }
  update(id: string, data: any)       { return this.put<any>(`/users/${id}`, data); }
  deleteUser(id: string)              { return this.remove<any>(`/users/${id}`); }
  assignRoles(id: string, data: any)  { return this.post<any>(`/users/${id}/roles`, data); }
  getPermissions(id: string)          { return this.get<any>(`/users/${id}/permissions`); }
  setPermissions(id: string, data: any) { return this.post<any>(`/users/${id}/permissions`, data); }
}

// ─── Role Service ─────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class RoleService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll()                            { return this.get<any>('/roles'); }
  getOne(id: string)                  { return this.get<any>(`/roles/${id}`); }
  create(data: any)                   { return this.post<any>('/roles', data); }
  update(id: string, data: any)       { return this.put<any>(`/roles/${id}`, data); }
  deleteRole(id: string)              { return this.remove<any>(`/roles/${id}`); }
  syncPermissions(id: string, data: any) { return this.put<any>(`/roles/${id}/permissions`, data); }
  getAllPermissions()                  { return this.get<any>('/permissions'); }
}

// ─── Supplier Service ─────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class SupplierService extends ApiService {
  constructor(http: HttpClient) { super(http); }

  getAll()                            { return this.get<any>('/suppliers'); }
  create(data: any)                   { return this.post<any>('/suppliers', data); }
  update(id: string, data: any)       { return this.put<any>(`/suppliers/${id}`, data); }
}
