// ─── Auth ────────────────────────────────────────────────────────────────────
export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  avatar?: string;
  jobTitle?: string;
  department?: string;
  isActive: boolean;
  isEmailVerified: boolean;
  lastLoginAt?: string;
  createdAt: string;
  roles?: Role[];
}

export interface AuthResponse {
  user: User;
  permissions: string[];
  accessToken: string;
  refreshToken: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

// ─── Role & Permission ───────────────────────────────────────────────────────
export interface Role {
  id: string;
  name: string;
  slug: string;
  description?: string;
  isSystem: boolean;
  color: string;
  permissions?: Permission[];
}

export interface Permission {
  id: string;
  name: string;
  resource: string;
  action: string;
  group?: string;
  description?: string;
}

// ─── Project ─────────────────────────────────────────────────────────────────
export interface Project {
  id: string;
  projectCode: string;
  name: string;
  description?: string;
  image?: string;
  status: 'active' | 'on_hold' | 'completed' | 'cancelled';
  startDate: string;
  endDate: string;
  client?: string;
  location?: string;
  totalBudget: number;
  currency: string;
  progress: number;
  createdAt: string;
  phases?: ProjectPhase[];
  teamMembers?: TeamMember[];
  budgetItems?: BudgetItem[];
}

export interface ProjectPhase {
  id: string;
  projectId: string;
  name: string;
  order: number;
  status: 'pending' | 'active' | 'completed' | 'on_hold';
  startDate: string;
  endDate: string;
  progress: number;
}

export interface ProjectOverview {
  project: Project;
  stats: {
    totalActivities: number;
    completed: number;
    inProgress: number;
    pending: number;
    totalBudget: number;
    totalPaid: number;
    daysRemaining: number;
  };
}

// ─── Activity ────────────────────────────────────────────────────────────────
export interface Activity {
  id: string;
  projectId: string;
  phaseId?: string;
  name: string;
  description?: string;
  category: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'on_hold';
  progress: number;
  startDate: string;
  dueDate: string;
  completedDate?: string;
  responsible?: User;
  phase?: ProjectPhase;
  notes?: string;
}

// ─── Procurement ─────────────────────────────────────────────────────────────
export interface Contract {
  id: string;
  projectId: string;
  contractNo: string;
  contractor: string;
  category?: string;
  contractValue: number;
  currency: string;
  startDate: string;
  endDate: string;
  status: 'draft' | 'active' | 'pending' | 'completed' | 'terminated';
}

export interface PurchaseOrder {
  id: string;
  projectId: string;
  poNumber: string;
  amount: number;
  currency: string;
  issuedDate?: string;
  status: 'open' | 'received' | 'partial' | 'closed' | 'cancelled';
  supplier?: Supplier;
}

export interface Supplier {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  category?: string;
  isActive: boolean;
}

// ─── Finance ─────────────────────────────────────────────────────────────────
export interface BudgetItem {
  id: string;
  projectId: string;
  category: string;
  budget: number;
  committed: number;
  paid: number;
  currency: string;
}

export interface Invoice {
  id: string;
  projectId: string;
  invoiceNo: string;
  description?: string;
  amount: number;
  tax: number;
  totalAmount: number;
  currency: string;
  invoiceDate: string;
  dueDate?: string;
  status: 'draft' | 'pending' | 'approved' | 'paid' | 'overdue' | 'cancelled';
  supplier?: Supplier;
  approvedBy?: User;
}

export interface Payment {
  id: string;
  projectId: string;
  paymentRef: string;
  amount: number;
  currency: string;
  paymentDate: string;
  paymentMethod?: string;
  status: 'pending' | 'pending_approval' | 'paid' | 'failed' | 'refunded';
  invoice?: Invoice;
}

export interface Expense {
  id: string;
  projectId: string;
  category: string;
  description?: string;
  amount: number;
  currency: string;
  expenseDate: string;
  status: 'draft' | 'pending' | 'approved' | 'rejected';
}

export interface FinanceOverview {
  totalBudget: number;
  totalCommitted: number;
  totalPaid: number;
  balance: number;
  retentionHeld: number;
  overdue: number;
  pendingApproval: number;
}

// ─── Report ──────────────────────────────────────────────────────────────────
export interface Report {
  id: string;
  projectId: string;
  reportNo: string;
  title: string;
  type: string;
  period?: string;
  status: 'draft' | 'in_progress' | 'completed' | 'approved' | 'pending' | 'overdue';
  progress: number;
  submittedBy?: User;
  submittedOn?: string;
  approvedBy?: User;
}

// ─── Document ────────────────────────────────────────────────────────────────
export interface Document {
  id: string;
  projectId: string;
  title: string;
  category?: string;
  fileName: string;
  fileSize?: number;
  mimeType?: string;
  version: string;
  uploadedBy?: User;
  createdAt: string;
}

// ─── Team ─────────────────────────────────────────────────────────────────────
export interface TeamMember {
  id: string;
  projectId: string;
  userId: string;
  role?: string;
  isActive: boolean;
  user?: User;
}

// ─── Letter ──────────────────────────────────────────────────────────────────
export interface CcRecipient {
  name: string;
  title?: string;
  email?: string;
}

export interface Letter {
  id: string;
  projectId?: string;
  letterNo: string;
  subject: string;
  body: string;
  letterDate: string;
  type: 'incoming' | 'outgoing' | 'internal' | 'memo';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'draft' | 'pending_approval' | 'approved' | 'sent' | 'received' | 'archived';
  fromName?: string;
  fromTitle?: string;
  fromOrg?: string;
  toName: string;
  toTitle?: string;
  toOrg?: string;
  toEmail?: string;
  ccRecipients?: CcRecipient[];
  attachmentName?: string;
  sentAt?: string;
  createdBy?: User;
  sentBy?: User;
  approvedBy?: User;
  referenceLetter?: Letter;
  referenceNo?: string;
  notes?: string;
  createdAt: string;
}

export interface LetterStats {
  total: number;
  sent: number;
  drafts: number;
  pendingApproval: number;
  incoming: number;
  outgoing: number;
}

// ─── Store ───────────────────────────────────────────────────────────────────
export interface StoreItem {
  id: string;
  projectId?: string;
  itemCode: string;
  name: string;
  description?: string;
  category?: string;
  unit: string;
  unitCost: number;
  currency: string;
  stockOnHand: number;
  stockReserved: number;
  reorderLevel: number;
  maxLevel?: number;
  location?: string;
  isActive: boolean;
  supplier?: Supplier;
}

export interface StoreReceipt {
  id: string;
  projectId?: string;
  receiptNo: string;
  purchaseOrderId?: string;
  receivedDate: string;
  deliveryNote?: string;
  invoiceRef?: string;
  status: 'draft' | 'received' | 'partial' | 'rejected';
  notes?: string;
  receivedBy?: User;
  supplier?: Supplier;
  lines?: StoreReceiptLine[];
}

export interface StoreReceiptLine {
  id: string;
  storeItemId: string;
  qtyOrdered: number;
  qtyReceived: number;
  qtyRejected: number;
  unitCost: number;
  totalCost: number;
  batchNo?: string;
  item?: StoreItem;
}

export interface StoreIssue {
  id: string;
  projectId?: string;
  issueNo: string;
  issueDate: string;
  issuedToName?: string;
  purpose?: string;
  status: 'draft' | 'pending_approval' | 'approved' | 'issued' | 'returned';
  notes?: string;
  requestedBy?: User;
  issuedTo?: User;
  approvedBy?: User;
  activity?: Activity;
  lines?: StoreIssueLine[];
}

export interface StoreIssueLine {
  id: string;
  storeItemId: string;
  qtyRequested: number;
  qtyIssued: number;
  qtyReturned: number;
  unitCost: number;
  totalCost: number;
  item?: StoreItem;
}

export interface StockTransaction {
  id: string;
  type: 'receipt' | 'issue' | 'return' | 'adjustment' | 'transfer';
  qty: number;
  balanceAfter: number;
  unitCost: number;
  referenceType?: string;
  notes?: string;
  createdBy?: User;
  createdAt: string;
}

export interface StoreOverview {
  totalItems: number;
  totalValue: number;
  receiptsThisMonth: number;
  issuesThisMonth: number;
  lowStockItems: StoreItem[];
}

// ─── API Response Wrappers ───────────────────────────────────────────────────
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

export interface PaginatedResponse<T> {
  success: boolean;
  message: string;
  data: T[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}
