import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FinanceService, ProjectService } from '../../../../../core/services/domain.services'; // rekebisha idadi ya '../'
import { SearchableSelectComponent } from '../../../../../shared/components/searchable-select/searchable-select.component'; // BADILISHA path/jina
import Swal from 'sweetalert2';

@Component({
  selector: 'app-budget-tab',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, SearchableSelectComponent],
  templateUrl: './budget-tab.component.html',
  styleUrls: ['./budget-tab.component.css'],
})
export class BudgetTabComponent implements OnChanges {
  @Input() projectId!: string;
  @Input() overview: any = {};

  budgetCategories: any[] = [];
  upcomingPayments: any[] = [];
  topExpenses: any[] = [];
  recentPayments: any[] = [];
  loading = false;

  showModal = false;
  editMode = false;
  selectedCategory: any = null;
  form!: FormGroup;
  saving = false;

  activityOptions: { value: string; label: string }[] = [];
  loadingActivities = false;

  constructor(
    private fb: FormBuilder,
    private financeSvc: FinanceService,
    private projectSvc: ProjectService,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['projectId'] && this.projectId) {
      this.loadBudget();
    }
  }

  loadBudget(): void {
    this.loading = true;
    this.financeSvc.getBudget(this.projectId).subscribe({
      next: (res: any) => {
        const data = res?.data || {};
        this.budgetCategories = data.categories || [];
        this.upcomingPayments = data.upcomingPayments || [];
        this.topExpenses = data.topExpenses || [];
        this.recentPayments = data.recentPayments || [];
        this.loading = false;
      },
      error: () => { this.loading = false; },
    });
  }

  get totals() {
    return this.budgetCategories.reduce(
      (acc, c) => ({
        budget: acc.budget + (+c.budget || 0),
        committed: acc.committed + (+c.committed || 0),
        paid: acc.paid + (+c.paid || 0),
        balance: acc.balance + (+c.balance || 0),
      }),
      { budget: 0, committed: 0, paid: 0, balance: 0 },
    );
  }

  progressPct(paid: number, budget: number): number {
    if (!budget) return 0;
    return (+paid / +budget) * 100;
  }

  formatCurrency(amount: number): string {
    return (+amount || 0).toLocaleString();
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      'Paid': 'status-completed',
      'Pending Approval': 'status-pending',
      'Overdue': 'status-overdue',
      'Open': 'status-pending',
    };
    return map[status] || 'status-pending';
  }

  // ══════════════════════════════════════════════════════════
  // BUDGET CATEGORY MODAL
  // ══════════════════════════════════════════════════════════

  loadActivities(): void {
    this.loadingActivities = true;
    this.projectSvc.getActivities(this.projectId).subscribe({
      next: (res: any) => {
        const activities = res?.data?.activities || res?.data?.rows || res?.data || [];
        this.activityOptions = activities
          .map((a: any) => ({ value: a.id, label: (a.name || '').toString().trim() }))
          .filter((o: any) => o.value && o.label);
        this.loadingActivities = false;
      },
      error: () => { this.loadingActivities = false; },
    });
  }

  openAddModal(): void {
    this.editMode = false;
    this.selectedCategory = null;
    this.form = this.fb.group({
      activityId: ['', Validators.required],
      budgetAmount: [null, [Validators.required, Validators.min(0)]],
      notes: [''],
    });
    this.loadActivities();
    this.showModal = true;
  }

  openEditModal(cat: any): void {
    this.editMode = true;
    this.selectedCategory = cat;
    this.form = this.fb.group({
      activityId: [cat.activityId || '', Validators.required],
      budgetAmount: [cat.budget, [Validators.required, Validators.min(0)]],
      notes: [cat.notes || ''],
    });
    this.loadActivities();
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
  }

  get f() {
    return this.form.controls;
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving = true;
    const payload = {
      ...this.form.value,
      id: this.editMode ? this.selectedCategory.id : undefined,
    };
    this.financeSvc.upsertBudget(this.projectId, payload).subscribe({
      next: (res: any) => {
        this.saving = false;
        this.showModal = false;
        this.loadBudget();
        Swal.fire({
          icon: 'success',
          title: res?.message || 'Budget saved!',
          timer: 1800,
          showConfirmButton: false,
        });
      },
      error: (err: any) => {
        this.saving = false;
        Swal.fire('Error', err?.error?.message || 'Failed to save budget category.', 'error');
      },
    });
  }

  deleteCategory(cat: any): void {
    Swal.fire({
      title: 'Delete Category?',
      text: `Delete budget category "${cat.category}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, delete!',
    }).then((r) => {
      if (!r.isConfirmed) return;
      this.financeSvc.deleteBudgetCategory(this.projectId, cat.id).subscribe({
        next: () => {
          this.loadBudget();
          Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false });
        },
        error: (err: any) => Swal.fire('Error', err?.error?.message || 'Failed.', 'error'),
      });
    });
  }
}
