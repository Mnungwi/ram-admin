import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FinanceService, ProjectService } from '../../../../../core/services/domain.services'; // rekebisha idadi ya '../'
import { SearchableSelectComponent } from '../../../../../shared/components/searchable-select/searchable-select.component'; // BADILISHA path/jina
import Swal from 'sweetalert2';

@Component({
  selector: 'app-invoices-tab',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, SearchableSelectComponent],
  templateUrl: './invoices-tab.component.html',
  styleUrls: ['./invoices-tab.component.css'],
})
export class InvoicesTabComponent implements OnChanges {
  @Input() projectId!: string;

  invoices: any[] = [];
  loading = false;

  showModal = false;
  editMode = false;
  selectedInvoice: any = null;
  form!: FormGroup;
  saving = false;

  activityOptions: { value: string; label: string }[] = [];
  loadingActivities = false;

  constructor(
    private fb: FormBuilder,
    private financeSvc: FinanceService,
    private projectSvc: ProjectService,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['projectId'] && this.projectId) {
      this.load();
    }
  }

  get f() {
    return this.form.controls;
  }

  load(): void {
    this.loading = true;
    this.financeSvc.getInvoices(this.projectId).subscribe({
      next: (res: any) => {
        this.invoices = res?.data?.invoices || res?.data?.rows || res?.data || [];
        this.loading = false;
      },
      error: () => { this.loading = false; },
    });
  }

  loadActivities(): void {
    this.loadingActivities = true;
    this.projectSvc.getActivities(this.projectId).subscribe({
      next: (res: any) => {
        const activities = res?.data?.activities || res?.data?.rows || res?.data || [];
        this.activityOptions = activities
          .map((a: any) => ({ value: a.id, label: (a.name || '').toString().trim() }))
          .filter((o: any) => o.value && o.label);
        this.loadingActivities = false;
      },
      error: () => { this.loadingActivities = false; },
    });
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      'Paid': 'status-completed',
      'Pending Approval': 'status-pending',
      'Approved': 'status-completed',
      'Overdue': 'status-overdue',
      'Open': 'status-pending',
    };
    return map[status] || 'status-pending';
  }

  private today(): string {
    return new Date().toISOString().slice(0, 10);
  }

  // ══════════════════════════════════════════════════════════
  // MODAL
  // ══════════════════════════════════════════════════════════

  openAddModal(): void {
    this.editMode = false;
    this.selectedInvoice = null;
    this.form = this.fb.group({
      activityId: [''],
      invoiceNo: ['', Validators.required],
      description: ['', Validators.required],
      amount: [null, [Validators.required, Validators.min(1)]],
      currency: ['TZS', Validators.required],
      date: [this.today(), Validators.required],
      dueDate: [''],
      notes: [''],
    });
    this.loadActivities();
    this.showModal = true;
  }

  openEditModal(inv: any): void {
    this.editMode = true;
    this.selectedInvoice = inv;
    this.form = this.fb.group({
      activityId: [inv.activityId || ''],
      invoiceNo: [inv.invoiceNo, Validators.required],
      description: [inv.description, Validators.required],
      amount: [inv.amount, [Validators.required, Validators.min(1)]],
      currency: [inv.currency || 'TZS', Validators.required],
      date: [inv.date, Validators.required],
      dueDate: [inv.dueDate || ''],
      notes: [inv.notes || ''],
    });
    this.loadActivities();
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving = true;
    const val = this.form.value;

    const call = this.editMode && this.selectedInvoice
      ? this.financeSvc.updateInvoice(this.projectId, this.selectedInvoice.id, val)
      : this.financeSvc.createInvoice(this.projectId, val);

    call.subscribe({
      next: (res: any) => {
        this.saving = false;
        this.showModal = false;
        this.load();
        Swal.fire({
          icon: 'success',
          title: res?.message || (this.editMode ? 'Invoice updated!' : 'Invoice created!'),
          timer: 1800,
          showConfirmButton: false,
        });
      },
      error: (err: any) => {
        this.saving = false;
        Swal.fire('Error', err?.error?.message || 'Failed to save invoice.', 'error');
      },
    });
  }

  approve(inv: any): void {
    Swal.fire({
      title: 'Approve Invoice?',
      text: `Approve invoice "${inv.invoiceNo}"?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, approve',
    }).then((r) => {
      if (!r.isConfirmed) return;
      this.financeSvc.approveInvoice(this.projectId, inv.id).subscribe({
        next: () => {
          this.load();
          Swal.fire({ icon: 'success', title: 'Approved!', timer: 1200, showConfirmButton: false });
        },
        error: (err: any) => Swal.fire('Error', err?.error?.message || 'Failed.', 'error'),
      });
    });
  }

  deleteInvoice(inv: any): void {
    Swal.fire({
      title: 'Delete Invoice?',
      text: `Delete invoice "${inv.invoiceNo}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, delete!',
    }).then((r) => {
      if (!r.isConfirmed) return;
      this.financeSvc.deleteInvoice(this.projectId, inv.id).subscribe({
        next: () => {
          this.load();
          Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false });
        },
        error: (err: any) => Swal.fire('Error', err?.error?.message || 'Failed.', 'error'),
      });
    });
  }
}
