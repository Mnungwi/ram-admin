import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProjectService, FinanceService } from '../../../core/services/domain.services';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-project-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './project-detail.component.html',
  styleUrl:'./project-detail.component.scss'
})
export class ProjectDetailComponent implements OnInit {
  project = signal<any>(null);
  overview = signal<any>(null);
  activities = signal<any[]>([]);
  invoices = signal<any[]>([]);
  financeOverview = signal<any>(null);
  teamMembers = signal<any[]>([]);
  documents = signal<any[]>([]);
  loading = signal(true);
  activeTab = signal('overview');
  showActivityForm = signal(false);

  projectId = '';

  tabs = [
    { key: 'overview',    label: 'Overview',    icon: 'speedometer2' },
    { key: 'activities',  label: 'Activities',  icon: 'list-check' },
    { key: 'finance',     label: 'Finance',     icon: 'cash' },
    { key: 'team',        label: 'Team',        icon: 'people' },
    { key: 'documents',   label: 'Documents',   icon: 'folder2' },
  ];

  constructor(
    private route: ActivatedRoute,
    private svc: ProjectService,
    private finance: FinanceService,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    this.projectId = this.route.snapshot.paramMap.get('id')!;
    this.loadAll();
  }

  loadAll(): void {
    this.svc.getOne(this.projectId).subscribe({
      next: (res: any) => {
        this.project.set(res.data?.project || res.data);
        this.loading.set(false);
      }
    });
    this.svc.getOverview(this.projectId).subscribe({ next: (r: any) => this.overview.set(r.data) });
    this.svc.getActivities(this.projectId).subscribe({ next: (r: any) => this.activities.set(r.data || []) });
    this.svc.getTeam(this.projectId).subscribe({ next: (r: any) => this.teamMembers.set(r.data?.members || []) });
    this.svc.getDocuments(this.projectId).subscribe({ next: (r: any) => this.documents.set(r.data?.documents || []) });
    if (this.auth.hasPermission('finance:view')) {
      this.finance.getOverview(this.projectId).subscribe({ next: (r: any) => this.financeOverview.set(r.data) });
      this.finance.getInvoices(this.projectId).subscribe({ next: (r: any) => this.invoices.set(r.data || []) });
    }
  }

  daysLeft(): number {
    if (!this.project()) return 0;
    return Math.ceil((new Date(this.project()!.endDate).getTime() - Date.now()) / 86400000);
  }

  formatSize(bytes?: number): string {
    if (!bytes) return '—';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  }
}
