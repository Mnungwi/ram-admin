import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProjectService } from '../../../core/services/domain.services';
import { AuthService } from '../../../core/services/auth.service';
import { Project } from '../../../core/models';

@Component({
  selector: 'app-projects-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
 templateUrl:'./projects-list.component.html'
})
export class ProjectsListComponent implements OnInit {
  projects = signal<Project[]>([]);
  loading = signal(true);
  view = signal<'table' | 'cards'>('table');
  pagination = signal({ total: 0, page: 1, limit: 20, totalPages: 1 });
  filters = { search: '', status: '' };

  constructor(private svc: ProjectService, public auth: AuthService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.svc.getAll({ ...this.filters, page: this.pagination().page, limit: 20 }).subscribe({
      next: (res: any) => {
        this.projects.set(res.data || []);
        if (res.pagination) this.pagination.set(res.pagination);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  changePage(p: number): void {
    if (p < 1 || p > this.pagination().totalPages) return;
    this.pagination.update(pag => ({ ...pag, page: p }));
    this.load();
  }

  getPages(): number[] {
    const total = this.pagination().totalPages;
    return Array.from({ length: Math.min(total, 5) }, (_, i) => i + 1);
  }

  min(a: number, b: number): number { return Math.min(a, b); }

  getProgressColor(pct: number): string {
    if (pct >= 80) return '#16a34a';
    if (pct >= 50) return '#2563eb';
    if (pct >= 25) return '#d97706';
    return '#ef4444';
  }

  getDays(endDate: string): number {
    return Math.ceil((new Date(endDate).getTime() - Date.now()) / 86400000);
  }

  getDaysClass(endDate: string): string {
    const d = this.getDays(endDate);
    if (d < 0)  return 'badge badge-overdue';
    if (d < 30) return 'badge badge-pending';
    return 'text-medium text-muted';
  }

  formatStatus(s: string): string {
    return s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }
}
