import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { ProjectService } from '../../../core/services/domain.services';

@Component({
  selector: 'app-project-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl:'./project-form.component.html',
  styles: [`
    .tip-item {
      display: flex; align-items: flex-start; gap: 10px;
      margin-bottom: 12px; font-size: 13px; color: #6b7280;
      i { font-size: 16px; flex-shrink: 0; margin-top: 1px; }
    }
  `]
})
export class ProjectFormComponent implements OnInit {
  form = this.fb.group({
    name:        ['', Validators.required],
    projectCode: [''],
    description: [''],
    client:      [''],
    location:    [''],
    startDate:   ['', Validators.required],
    endDate:     ['', Validators.required],
    totalBudget: [0],
    currency:    ['TZS'],
  });

  loading = signal(false);
  error = signal('');
  isEdit = false;
  projectId = '';

  get f() { return this.form.controls; }

  constructor(
    private fb: FormBuilder,
    private svc: ProjectService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.projectId = this.route.snapshot.paramMap.get('id') || '';
    this.isEdit = !!this.projectId && this.route.snapshot.url.some(s => s.path === 'edit');

    if (this.isEdit) {
      this.svc.getOne(this.projectId).subscribe({
        next: (res: any) => {
          const p = res.data?.project || res.data;
          this.form.patchValue(p);
        }
      });
    }
  }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading.set(true);
    this.error.set('');

    const obs = this.isEdit
      ? this.svc.update(this.projectId, this.form.value)
      : this.svc.create(this.form.value);

    obs.subscribe({
      next: (res: any) => {
        const id = res.data?.project?.id || this.projectId;
        this.router.navigate(['/projects', id]);
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err.error?.message || 'Failed to save project');
      }
    });
  }
}
