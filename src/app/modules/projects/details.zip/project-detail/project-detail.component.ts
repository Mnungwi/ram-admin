import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet, ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../../core/services/data.service';
import { Project } from '../../../core/models/models';

@Component({
  selector: 'app-project-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.css']
})
export class ProjectDetailComponent implements OnInit {
  project: Project | undefined;
  projectId = '';

  constructor(private route: ActivatedRoute, private router: Router, private data: DataService) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.projectId = params['id'];
      this.project = this.data.getProject(this.projectId);
    });
  }

  getStatusClass(s: string): string {
    const m: any = { 'Active': 'badge-active', 'On Hold': 'badge-on-hold', 'Completed': 'badge-completed', 'Cancelled': 'badge-overdue' };
    return m[s] || 'badge-pending';
  }

  getCurrentTab(): string {
    const url = this.router.url;
    const segments = url.split('/');
    return segments[segments.length - 1] || 'overview';
  }
}
