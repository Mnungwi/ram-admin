import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataService } from '../../../core/services/data.service';
import { Project } from '../../../core/models/models';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-project-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ReactiveFormsModule],
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {
  projects: Project[] = [];
  filteredProjects: Project[] = [];
  searchTerm = '';
  statusFilter = '';
  showModal = false;
  editMode = false;
  selectedProject: Project | null = null;
  form!: FormGroup;

  constructor(private data: DataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.data.getProjects().subscribe(p => {
      this.projects = p;
      this.applyFilters();
    });
    this.initForm();
  }

  initForm(project?: Project) {
    this.form = this.fb.group({
      name: [project?.name || '', [Validators.required, Validators.minLength(3)]],
      code: [project?.code || '', Validators.required],
      client: [project?.client || '', Validators.required],
      status: [project?.status || 'Active', Validators.required],
      startDate: [project?.startDate || '', Validators.required],
      endDate: [project?.endDate || '', Validators.required],
      budget: [project?.budget || '', [Validators.required, Validators.min(0)]],
      currency: [project?.currency || 'TZS', Validators.required],
      description: [project?.description || ''],
      location: [project?.location || ''],
      projectManager: [project?.projectManager || '']
    });
  }

  applyFilters() {
    this.filteredProjects = this.projects.filter(p => {
      const matchSearch = !this.searchTerm || p.name.toLowerCase().includes(this.searchTerm.toLowerCase()) || p.code.toLowerCase().includes(this.searchTerm.toLowerCase());
      const matchStatus = !this.statusFilter || p.status === this.statusFilter;
      return matchSearch && matchStatus;
    });
  }

  openAddModal() {
    this.editMode = false;
    this.selectedProject = null;
    this.initForm();
    this.showModal = true;
  }

  openEditModal(p: Project) {
    this.editMode = true;
    this.selectedProject = p;
    this.initForm(p);
    this.showModal = true;
  }

  closeModal() { this.showModal = false; }

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value;
    if (this.editMode && this.selectedProject) {
      const updated: Project = { ...this.selectedProject, ...val, progress: this.selectedProject.progress, daysRemaining: this.selectedProject.daysRemaining };
      this.data.updateProject(updated);
      Swal.fire({ icon: 'success', title: 'Updated!', text: 'Project updated successfully.', timer: 1800, showConfirmButton: false });
    } else {
      const newProject: Project = {
        id: `PROJ-${Date.now()}`, ...val, progress: 0, daysRemaining: 0
      };
      this.data.addProject(newProject);
      Swal.fire({ icon: 'success', title: 'Created!', text: 'Project created successfully.', timer: 1800, showConfirmButton: false });
    }
    this.closeModal();
  }

  deleteProject(p: Project) {
    Swal.fire({
      title: 'Delete Project?',
      text: `Are you sure you want to delete "${p.name}"? This action cannot be undone.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel'
    }).then(result => {
      if (result.isConfirmed) {
        this.data.deleteProject(p.id);
        Swal.fire({ icon: 'success', title: 'Deleted!', text: 'Project has been deleted.', timer: 1500, showConfirmButton: false });
      }
    });
  }

  getStatusClass(s: string): string {
    const m: any = { 'Active': 'status-active', 'On Hold': 'status-on-hold', 'Completed': 'status-completed', 'Cancelled': 'status-overdue' };
    return m[s] || 'status-pending';
  }

  formatCurrency(n: number): string { return this.data.formatCurrency(n); }
  get f() { return this.form.controls; }
}
