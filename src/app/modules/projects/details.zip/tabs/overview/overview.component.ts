import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Project, Phase, Activity, Payment } from '../../../../core/models/models';

@Component({
  selector: 'app-overview',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})
export class OverviewComponent implements OnInit {
  project: Project | undefined;
  projectId = '';
  phases: Phase[] = [];
  recentActivities: Activity[] = [];
  recentPayments: Payment[] = [];
  totalActivities = 111;
  completedActivities = 40;
  inProgressActivities = 21;
  pendingActivities = 50;
  overdueActivities = 2;

  constructor(private route: ActivatedRoute, private data: DataService) {}

  ngOnInit() {
    this.route.parent?.params.subscribe(params => {
      this.projectId = params['id'];
      this.project = this.data.getProject(this.projectId);
      this.phases = this.data.getPhases(this.projectId);
      this.data.getActivities(this.projectId).subscribe(a => {
        this.recentActivities = a.slice(0, 5);
      });
      this.data.getPayments(this.projectId).subscribe(p => {
        this.recentPayments = p.filter(x => x.status === 'Paid').slice(0, 3);
      });
    });
  }

  getProgressColor(n: number): string {
    if (n >= 75) return '#10b981';
    if (n >= 40) return '#f59e0b';
    return '#1a56db';
  }

  getStatusClass(s: string): string {
    const m: any = { 'Completed': 'status-completed', 'In Progress': 'status-in-progress', 'Pending': 'status-pending', 'Overdue': 'status-overdue', 'Active': 'status-active' };
    return m[s] || 'status-pending';
  }

  getPhaseBarColor(phase: Phase): string {
    const colors: any = { 'PH1': '#1a56db', 'PH2': '#f59e0b', 'PH3': '#7c3aed', 'PH4': '#10b981' };
    return colors[phase.id] || '#1a56db';
  }

  getBudgetPaidPct(): number {
    if (!this.project) return 0;
    return Math.round((210650000 / this.project.budget) * 100);
  }

  getBudgetCommittedPct(): number {
    if (!this.project) return 0;
    return Math.round((120400000 / this.project.budget) * 100);
  }

  formatCurrency(n: number): string { return this.data.formatCurrency(n, 'TZS'); }

  getUpcomingDeadlines() {
    return [
      { day: '20', month: 'MAY', title: 'Site Inspection', sub: 'Inspection & Testing', days: 5, type: 'danger' },
      { day: '15', month: 'JUN', title: 'Material Delivery', sub: 'Electrical Installation', days: 31, type: 'warning' },
      { day: '30', month: 'JUN', title: 'Progress Report', sub: 'Construction Phase 1', days: 46, type: 'info' }
    ];
  }

  getLatestDocuments() {
    return [
      { name: 'Contract Agreement.pdf', category: 'Contracts', date: '12 May 2026', size: '2.4 MB', icon: 'pdf' },
      { name: 'Site Plan Drawing.dwg', category: 'Drawings', date: '10 May 2026', size: '5.7 MB', icon: 'dwg' },
      { name: 'Progress Report Apr 2026.pdf', category: 'Reports', date: '05 May 2026', size: '1.8 MB', icon: 'pdf' }
    ];
  }
}
