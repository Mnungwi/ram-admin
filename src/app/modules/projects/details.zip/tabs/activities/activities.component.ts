import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Activity } from '../../../../core/models/models';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-activities',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.css']
})
export class ActivitiesComponent implements OnInit {
  projectId = '';
  activities: Activity[] = [];
  filteredActivities: Activity[] = [];
  searchTerm = '';
  statusFilter = '';
  phaseFilter = '';
  showModal = false;
  editMode = false;
  selectedActivity: Activity | null = null;
  form!: FormGroup;
  currentPage = 1;
  pageSize = 10;
  totalPages = 1;

  phases = [
    { id: 'PH1', name: 'Phase 1: Pre-Construction & Mobilization' },
    { id: 'PH2', name: 'Phase 2: Construction Works' },
    { id: 'PH3', name: 'Phase 3: Finishing & Installation' },
    { id: 'PH4', name: 'Phase 4: Testing, Commissioning & Handover' }
  ];

  activityTypes = ['Mobilization', 'Survey', 'Assessment', 'Design', 'Procurement', 'Administration', 'Infrastructure', 'Setup', 'Construction', 'Electrical', 'Plumbing', 'HVAC', 'Civil Works', 'Finishing', 'Landscaping', 'Testing', 'Inspection', 'Handover', 'Other'];

  get totalActivities() { return this.activities.length; }
  get completedCount() { return this.activities.filter(a => a.status === 'Completed').length; }
  get inProgressCount() { return this.activities.filter(a => a.status === 'In Progress').length; }
  get pendingCount() { return this.activities.filter(a => a.status === 'Pending').length; }
  get overdueCount() { return this.activities.filter(a => a.status === 'Overdue').length; }

  get paginatedActivities(): Activity[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredActivities.slice(start, start + this.pageSize);
  }

  constructor(private route: ActivatedRoute, private data: DataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.route.parent?.params.subscribe(params => {
      this.projectId = params['id'];
      this.data.getActivities(this.projectId).subscribe(a => {
        this.activities = a;
        this.applyFilters();
      });
    });
    this.initForm();
  }

  initForm(a?: Activity) {
    this.form = this.fb.group({
      name: [a?.name || '', [Validators.required, Validators.minLength(3)]],
      type: [a?.type || '', Validators.required],
      phaseId: [a?.phaseId || '', Validators.required],
      status: [a?.status || 'Pending', Validators.required],
      priority: [a?.priority || 'Medium', Validators.required],
      progress: [a?.progress ?? 0, [Validators.required, Validators.min(0), Validators.max(100)]],
      startDate: [a?.startDate || '', Validators.required],
      dueDate: [a?.dueDate || '', Validators.required],
      assignedTo: [a?.assignedTo || ''],
      description: [a?.description || '']
    });
  }

  applyFilters() {
    this.filteredActivities = this.activities.filter(a => {
      const s = this.searchTerm.toLowerCase();
      const matchSearch = !s || a.name.toLowerCase().includes(s) || a.type.toLowerCase().includes(s) || (a.assignedTo || '').toLowerCase().includes(s);
      const matchStatus = !this.statusFilter || a.status === this.statusFilter;
      const matchPhase = !this.phaseFilter || a.phaseId === this.phaseFilter;
      return matchSearch && matchStatus && matchPhase;
    });
    this.totalPages = Math.ceil(this.filteredActivities.length / this.pageSize);
    this.currentPage = 1;
  }

  openAddModal() {
    this.editMode = false; this.selectedActivity = null;
    this.initForm(); this.showModal = true;
  }

  openEditModal(a: Activity) {
    this.editMode = true; this.selectedActivity = a;
    this.initForm(a); this.showModal = true;
  }

  closeModal() { this.showModal = false; }

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value;
    if (this.editMode && this.selectedActivity) {
      const updated: Activity = { ...this.selectedActivity, ...val };
      this.data.updateActivity(updated);
      Swal.fire({ icon: 'success', title: 'Updated!', text: 'Activity updated.', timer: 1500, showConfirmButton: false });
    } else {
      const newActivity: Activity = {
        id: this.data.generateId('ACT'), projectId: this.projectId, ...val
      };
      this.data.addActivity(newActivity);
      Swal.fire({ icon: 'success', title: 'Added!', text: 'Activity added.', timer: 1500, showConfirmButton: false });
    }
    this.closeModal();
  }

  deleteActivity(a: Activity) {
    Swal.fire({
      title: 'Delete Activity?',
      text: `Delete "${a.name}"?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Yes, delete!'
    }).then(result => {
      if (result.isConfirmed) {
        this.data.deleteActivity(a.id);
        Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false });
      }
    });
  }

  getStatusClass(s: string): string {
    const m: any = { 'Completed': 'status-completed', 'In Progress': 'status-in-progress', 'Pending': 'status-pending', 'Overdue': 'status-overdue' };
    return m[s] || 'status-pending';
  }

  getPriorityClass(p: string): string {
    const m: any = { 'High': 'badge-danger', 'Medium': 'badge-warning', 'Low': 'badge-info' };
    return m[p] || 'badge-info';
  }

  getPhaseName(id?: string): string {
    return this.phases.find(p => p.id === id)?.name.split(':')[0] || 'N/A';
  }

  changePage(p: number) {
    if (p >= 1 && p <= this.totalPages) this.currentPage = p;
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  get f() { return this.form.controls; }
}
