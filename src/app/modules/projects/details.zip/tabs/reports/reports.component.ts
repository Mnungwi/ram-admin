import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Report, Phase } from '../../../../core/models/models';
import Swal from 'sweetalert2';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit, AfterViewInit {
  projectId = '';
  activeTab = 'summary';
  reports: Report[] = [];
  filteredReports: Report[] = [];
  phases: Phase[] = [];
  showModal = false;
  editMode = false;
  selectedReport: Report | null = null;
  form!: FormGroup;
  searchTerm = '';
  filterType = 'All Report Types';
  filterStatus = 'All Status';
  currentPage = 1;
  pageSize = 8;
  expandedPhases: Set<string> = new Set();
  private charts: Chart[] = [];

  reportTypes = ['Progress Report', 'Test Report', 'RFI Report', 'Inspection Report', 'Completion Report', 'Environmental Report'];
  statuses = ['Completed', 'In Progress', 'Pending', 'Overdue'];

  upcomingReports = [
    { title: 'Monthly Progress Report - June 2026', date: '05 Jun 2026' },
    { title: 'Site Inspection Report - May 2026', date: '15 May 2026' },
    { title: 'Concrete Test Report - May 2026', date: '20 May 2026' },
  ];

  latestReports = [
    { title: 'Monthly Progress Report - May 2026', status: 'Completed' },
    { title: 'Concrete Strength Test Report', status: 'Completed' },
    { title: 'RFI - Drainage Design Clarification', status: 'In Progress' },
  ];

  constructor(private route: ActivatedRoute, private data: DataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.route.parent?.params.subscribe(params => {
      this.projectId = params['id'];
      this.data.getReports(this.projectId).subscribe(r => {
        this.reports = r;
        this.applyFilters();
      });
      this.phases = this.data.getPhases(this.projectId);
    });
    this.initForm();
  }

  ngAfterViewInit() {
    if (this.activeTab === 'summary') setTimeout(() => this.initCharts(), 300);
  }

  setTab(t: string) {
    this.activeTab = t;
    if (t === 'summary') setTimeout(() => this.initCharts(), 300);
  }

  togglePhase(phaseId: string) {
    if (this.expandedPhases.has(phaseId)) this.expandedPhases.delete(phaseId);
    else this.expandedPhases.add(phaseId);
  }

  isExpanded(phaseId: string) { return this.expandedPhases.has(phaseId); }

  getPhaseReports(phaseId: string) {
    return this.reports.filter(r => r.phaseId === phaseId).slice(0, 4);
  }

  getPhaseStats(phase: Phase) {
    const phaseReports = this.reports.filter(r => r.phaseId === phase.id);
    return {
      completed: phaseReports.filter(r => r.status === 'Completed').length,
      inProgress: phaseReports.filter(r => r.status === 'In Progress').length,
      pending: phaseReports.filter(r => r.status === 'Pending').length,
      overdue: phaseReports.filter(r => r.status === 'Overdue').length,
      total: phaseReports.length
    };
  }

  getPhaseStatusClass(status: string) {
    const map: any = { 'Active': 'badge-active', 'In Progress': 'badge-in-progress', 'Pending': 'badge-pending', 'Completed': 'badge-completed' };
    return map[status] || 'badge-pending';
  }

  getPhaseColor(i: number) {
    const colors = ['#3b82f6','#f59e0b','#a855f7','#22c55e'];
    return colors[i % colors.length];
  }

  applyFilters() {
    let r = [...this.reports];
    if (this.searchTerm) r = r.filter(x => x.title.toLowerCase().includes(this.searchTerm.toLowerCase()) || x.reportNo.toLowerCase().includes(this.searchTerm.toLowerCase()));
    if (this.filterType !== 'All Report Types') r = r.filter(x => x.type === this.filterType);
    if (this.filterStatus !== 'All Status') r = r.filter(x => x.status === this.filterStatus);
    this.filteredReports = r;
    this.currentPage = 1;
  }

  get pagedReports() {
    const s = (this.currentPage - 1) * this.pageSize;
    return this.filteredReports.slice(s, s + this.pageSize);
  }

  get totalPages() { return Math.ceil(this.filteredReports.length / this.pageSize); }
  get pages() { return Array.from({ length: this.totalPages }, (_, i) => i + 1); }

  initCharts() {
    this.destroyCharts();
    this.initTypeDonut();
    this.initStatusDonut();
    this.initTrendChart();
  }

  destroyCharts() { this.charts.forEach(c => c.destroy()); this.charts = []; }

  initTypeDonut() {
    const el = document.getElementById('reportTypeChart') as HTMLCanvasElement;
    if (!el) return;
    const c = new Chart(el, {
      type: 'doughnut',
      data: {
        labels: ['Progress Reports','Test Reports','RFI Reports','Inspection Reports','Completion Reports'],
        datasets: [{ data: [12,6,5,3,2], backgroundColor: ['#3b82f6','#22c55e','#f59e0b','#a855f7','#ef4444'], borderWidth: 0 }]
      },
      options: {
        cutout: '65%', responsive: true, maintainAspectRatio: true,
        plugins: { legend: { display: false } }
      }
    });
    this.charts.push(c);
  }

  initStatusDonut() {
    const el = document.getElementById('reportStatusChart') as HTMLCanvasElement;
    if (!el) return;
    const c = new Chart(el, {
      type: 'doughnut',
      data: {
        labels: ['Completed','In Progress','Pending','Overdue'],
        datasets: [{ data: [12,10,6,2], backgroundColor: ['#22c55e','#3b82f6','#f59e0b','#ef4444'], borderWidth: 0 }]
      },
      options: {
        cutout: '65%', responsive: true, maintainAspectRatio: true,
        plugins: { legend: { display: false } }
      }
    });
    this.charts.push(c);
  }

  initTrendChart() {
    const el = document.getElementById('reportTrendChart') as HTMLCanvasElement;
    if (!el) return;
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const c = new Chart(el, {
      type: 'bar',
      data: {
        labels: months,
        datasets: [
          { label:'Completed', data:[2,3,4,3,5,0,0,0,0,0,0,0], backgroundColor:'#22c55e', borderRadius:3 },
          { label:'In Progress', data:[1,2,2,3,2,0,0,0,0,0,0,0], backgroundColor:'#3b82f6', borderRadius:3 },
          { label:'Total', data:[3,5,7,7,8,0,0,0,0,0,0,0], type:'line' as any, borderColor:'#f59e0b', borderDash:[4,4], pointRadius:3, fill:false, tension:.4 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: true,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero:true, grid:{ color:'#f3f4f6' }, ticks:{ stepSize:5 } },
          x: { grid:{ display:false } }
        }
      }
    });
    this.charts.push(c);
  }

  initForm(r?: Report) {
    this.form = this.fb.group({
      title: [r?.title || '', Validators.required],
      reportNo: [r?.reportNo || '', Validators.required],
      type: [r?.type || 'Progress Report', Validators.required],
      subject: [r?.subject || '', Validators.required],
      status: [r?.status || 'Pending', Validators.required],
      submittedBy: [r?.submittedBy || '', Validators.required],
      submittedOn: [r?.submittedOn || ''],
      progress: [r?.progress ?? 0, [Validators.required, Validators.min(0), Validators.max(100)]],
      phaseId: [r?.phaseId || '']
    });
  }

  openAddModal() { this.editMode = false; this.selectedReport = null; this.initForm(); this.showModal = true; }
  openEditModal(r: Report) { this.editMode = true; this.selectedReport = r; this.initForm(r); this.showModal = true; }
  closeModal() { this.showModal = false; }

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value;
    if (this.editMode && this.selectedReport) {
      this.data.updateReport({ ...this.selectedReport, ...val });
      Swal.fire({ icon: 'success', title: 'Report Updated!', timer: 1500, showConfirmButton: false });
    } else {
      this.data.addReport({ id: this.data.generateId('RPT'), projectId: this.projectId, ...val });
      Swal.fire({ icon: 'success', title: 'Report Added!', timer: 1500, showConfirmButton: false });
    }
    this.closeModal();
  }

  deleteReport(r: Report) {
    Swal.fire({ title: 'Delete Report?', text: `Delete "${r.title}"?`, icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444', confirmButtonText: 'Yes, delete!' })
      .then(res => { if (res.isConfirmed) { this.data.deleteReport(r.id); Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false }); } });
  }

  getTypeClass(t: string) {
    const m: any = {
      'Progress Report': 'type-progress', 'Test Report': 'type-test',
      'RFI Report': 'type-rfi', 'Inspection Report': 'type-inspection',
      'Completion Report': 'type-completion', 'Environmental Report': 'type-env'
    };
    return m[t] || 'type-progress';
  }

  getStatusClass(s: string) {
    const m: any = { 'Completed': 'status-completed', 'In Progress': 'status-in-progress', 'Pending': 'status-pending', 'Overdue': 'status-overdue' };
    return m[s] || 'status-pending';
  }

  get totalReports() { return this.reports.length; }
  get completedReports() { return this.reports.filter(r => r.status === 'Completed').length; }
  get inProgressReports() { return this.reports.filter(r => r.status === 'In Progress').length; }
  get pendingReports() { return this.reports.filter(r => r.status === 'Pending').length; }
  get overdueReports() { return this.reports.filter(r => r.status === 'Overdue').length; }
  get f() { return this.form.controls; }
  get Math() { return Math; }
}
