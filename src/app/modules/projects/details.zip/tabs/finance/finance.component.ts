import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Payment, FinanceBudgetCategory, Invoice } from '../../../../core/models/models';
import Swal from 'sweetalert2';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

@Component({
  selector: 'app-finance',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './finance.component.html',
  styleUrls: ['./finance.component.css']
})
export class FinanceComponent implements OnInit, AfterViewInit {
  projectId = '';
  activeTab = 'budget';
  budgetCategories: FinanceBudgetCategory[] = [];
  payments: Payment[] = [];
  invoices: Invoice[] = [];
  showModal = false;
  editMode = false;
  selectedPayment: Payment | null = null;
  form!: FormGroup;
  private charts: Chart[] = [];

  totalBudget = 450000000;
  totalCommitted = 320750000;
  totalPaid = 210650000;
  totalBalance = 239350000;
  retentionHeld = 18400000;

  topExpenses = [
    { category: 'Civil Works', amount: 82500000, color: '#3b82f6' },
    { category: 'Electrical Works', amount: 24750000, color: '#f59e0b' },
    { category: 'HVAC Works', amount: 21200000, color: '#22c55e' },
    { category: 'Finishes', amount: 18600000, color: '#a855f7' },
    { category: 'External Works', amount: 15300000, color: '#ef4444' },
  ];

  constructor(private route: ActivatedRoute, private data: DataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.route.parent?.params.subscribe(params => {
      this.projectId = params['id'];
      this.budgetCategories = this.data.getBudgetCategories();
      this.data.getPayments(this.projectId).subscribe(p => this.payments = p);
      this.invoices = this.data.getInvoices ? this.data.getInvoices(this.projectId) : this.getMockInvoices();
    });
    this.initForm();
  }

  ngAfterViewInit() {
    setTimeout(() => this.initCharts(), 200);
  }

  getMockInvoices(): Invoice[] {
    return [
      { id:'inv1', projectId:this.projectId, invoiceNo:'INV-2026-018', description:'Payment for Construction Phase 1', date:'10 May 2026', dueDate:'15 May 2026', amount:25000000, status:'Paid', currency:'TZS' },
      { id:'inv2', projectId:this.projectId, invoiceNo:'INV-2026-017', description:'Payment for Materials', date:'28 Apr 2026', dueDate:'05 May 2026', amount:18500000, status:'Paid', currency:'TZS' },
      { id:'inv3', projectId:this.projectId, invoiceNo:'INV-2026-016', description:'Advance Payment', date:'15 Apr 2026', dueDate:'20 Apr 2026', amount:50000000, status:'Paid', currency:'TZS' },
      { id:'inv4', projectId:this.projectId, invoiceNo:'INV-2026-024', description:'Civil Works - Stage 3', date:'01 May 2026', dueDate:'20 May 2026', amount:22000000, status:'Pending Approval', currency:'TZS' },
      { id:'inv5', projectId:this.projectId, invoiceNo:'INV-2026-025', description:'Electrical Installation', date:'15 May 2026', dueDate:'05 Jun 2026', amount:15500000, status:'Pending Approval', currency:'TZS' },
    ];
  }

  initCharts() {
    this.destroyCharts();
    this.initBudgetDonut();
    this.initCashFlow();
  }

  destroyCharts() {
    this.charts.forEach(c => c.destroy());
    this.charts = [];
  }

  initBudgetDonut() {
    const el = document.getElementById('budgetDonutChart') as HTMLCanvasElement;
    if (!el) return;
    const c = new Chart(el, {
      type: 'doughnut',
      data: {
        labels: ['Paid', 'Committed', 'Balance'],
        datasets: [{ data: [210.65, 320.75, 239.35], backgroundColor: ['#22c55e','#3b82f6','#f59e0b'], borderWidth: 0 }]
      },
      options: {
        cutout: '70%', responsive: true, maintainAspectRatio: true,
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: (c) => ` ${c.label}: ${c.raw}M TZS` } }
        }
      }
    });
    this.charts.push(c);
  }

  initCashFlow() {
    const el = document.getElementById('cashFlowChart') as HTMLCanvasElement;
    if (!el) return;
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const planned = [30,35,28,42,38,45,40,50,35,48,55,60];
    const actual  = [25,32,30,38,35,0,0,0,0,0,0,0];
    const cumActual = actual.map((_, i) => actual.slice(0,i+1).reduce((a,b)=>a+b,0)/10);
    const c = new Chart(el, {
      type: 'bar',
      data: {
        labels: months,
        datasets: [
          { label:'Planned', data:planned, backgroundColor:'#22c55e', borderRadius:4 },
          { label:'Actual', data:actual, backgroundColor:'#3b82f6', borderRadius:4 },
          { label:'Cumulative Actual', data:cumActual, type:'line' as any, borderColor:'#f59e0b', borderDash:[5,5], pointRadius:3, fill:false, tension:.4 }
        ]
      },
      options: {
        responsive:true, maintainAspectRatio:true,
        plugins: { legend:{ display:false } },
        scales: {
          y: { beginAtZero:true, grid:{ color:'#f3f4f6' }, ticks:{ callback:(v)=>`${v}M` } },
          x: { grid:{ display:false } }
        }
      }
    });
    this.charts.push(c);
  }

  setTab(t: string) {
    this.activeTab = t;
    if (t === 'budget') setTimeout(() => this.initCharts(), 200);
  }

  initForm(p?: Payment) {
    this.form = this.fb.group({
      invoiceNo: [p?.invoiceNo || '', Validators.required],
      description: [p?.description || '', Validators.required],
      date: [p?.date || '', Validators.required],
      dueDate: [p?.dueDate || ''],
      amount: [p?.amount || '', [Validators.required, Validators.min(1)]],
      currency: [p?.currency || 'TZS', Validators.required],
      status: [p?.status || 'Pending Approval', Validators.required]
    });
  }

  openAddModal() { this.editMode = false; this.selectedPayment = null; this.initForm(); this.showModal = true; }
  openEditModal(p: Payment) { this.editMode = true; this.selectedPayment = p; this.initForm(p); this.showModal = true; }
  closeModal() { this.showModal = false; }

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value;
    if (this.editMode && this.selectedPayment) {
      this.data.updatePayment({ ...this.selectedPayment, ...val });
      Swal.fire({ icon: 'success', title: 'Updated!', timer: 1500, showConfirmButton: false });
    } else {
      this.data.addPayment({ id: this.data.generateId('PAY'), projectId: this.projectId, ...val });
      Swal.fire({ icon: 'success', title: 'Payment Added!', timer: 1500, showConfirmButton: false });
    }
    this.closeModal();
  }

  deletePayment(p: Payment) {
    Swal.fire({ title: 'Delete Payment?', text: `Delete "${p.invoiceNo}"?`, icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444', confirmButtonText: 'Yes, delete it!' })
      .then(r => { if (r.isConfirmed) { this.data.deletePayment(p.id); Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false }); } });
  }

  getStatusClass(s: string): string {
    const m: any = { 'Paid': 'status-completed', 'Pending Approval': 'status-pending', 'Overdue': 'status-overdue', 'Open': 'status-in-progress' };
    return m[s] || 'status-pending';
  }

  formatCurrency(n: number, short = true): string {
    if (short && n >= 1000000) return `${(n / 1000000).toFixed(2)}M TZS`;
    return n.toLocaleString() + ' TZS';
  }

  pct(n: number): string { return ((n / this.totalBudget) * 100).toFixed(2) + '%'; }
  get f() { return this.form.controls; }
  get paidPayments(): Payment[] { return this.payments.filter(p => p.status === 'Paid'); }
  get pendingPayments(): Payment[] { return this.payments.filter(p => p.status === 'Pending Approval'); }
}
