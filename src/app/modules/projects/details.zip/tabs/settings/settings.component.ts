import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Project } from '../../../../core/models/models';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  projectId = '';
  project: Project | null = null;
  activeSection = 'general';
  form!: FormGroup;
  saving = false;

  sections = [
    { id:'general', label:'General', icon:'fa-cog' },
    { id:'notifications', label:'Notifications', icon:'fa-bell' },
    { id:'permissions', label:'Permissions', icon:'fa-shield-alt' },
    { id:'budget', label:'Budget Settings', icon:'fa-dollar-sign' },
    { id:'integrations', label:'Integrations', icon:'fa-plug' },
    { id:'danger', label:'Danger Zone', icon:'fa-exclamation-triangle' }
  ];

  notifications = {
    emailOnActivity: true, emailOnPayment: true, emailOnReport: false,
    smsOnOverdue: true, weeklyDigest: true, budgetAlerts: true
  };

  constructor(private route: ActivatedRoute, private router: Router, private data: DataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.route.parent?.params.subscribe(params => {
      this.projectId = params['id'];
      this.data.getProjects().subscribe(projects => {
        this.project = projects.find(p => p.id === this.projectId) || null;
        if (this.project) this.initForm(this.project);
      });
    });
  }

  initForm(p: Project) {
    this.form = this.fb.group({
      name: [p.name, Validators.required],
      code: [p.code, Validators.required],
      client: [p.client, Validators.required],
      status: [p.status, Validators.required],
      startDate: [p.startDate, Validators.required],
      endDate: [p.endDate, Validators.required],
      totalBudget: [p.totalBudget, [Validators.required, Validators.min(0)]],
      currency: ['TZS', Validators.required],
      description: [p.description || ''],
      location: [p.location || 'Zanzibar, Tanzania'],
      contractor: [p.contractor || ''],
      category: [p.category || 'Construction']
    });
  }

  setSection(s: string) { this.activeSection = s; }

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving = true;
    setTimeout(() => {
      if (this.project) {
        this.data.updateProject({ ...this.project, ...this.form.value });
      }
      this.saving = false;
      Swal.fire({ icon: 'success', title: 'Settings Saved!', text: 'Project settings have been updated.', timer: 2000, showConfirmButton: false });
    }, 600);
  }

  archiveProject() {
    Swal.fire({ title: 'Archive Project?', text: 'This project will be archived and hidden from active view.', icon: 'warning', showCancelButton: true, confirmButtonColor: '#f59e0b', confirmButtonText: 'Yes, archive!' })
      .then(r => { if (r.isConfirmed) Swal.fire({ icon: 'success', title: 'Archived!', timer: 1500, showConfirmButton: false }); });
  }

  deleteProject() {
    Swal.fire({
      title: 'Delete Project?',
      text: 'This action is IRREVERSIBLE. All data for this project will be permanently deleted.',
      icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444',
      confirmButtonText: 'Yes, permanently delete!', input: 'text',
      inputPlaceholder: `Type "${this.project?.name}" to confirm`,
      preConfirm: (val) => {
        if (val !== this.project?.name) { Swal.showValidationMessage('Project name does not match!'); return false; }
        return true;
      }
    }).then(r => {
      if (r.isConfirmed) {
        Swal.fire({ icon: 'success', title: 'Deleted!', text: 'Project has been deleted.', timer: 2000, showConfirmButton: false })
          .then(() => this.router.navigate(['/projects']));
      }
    });
  }

  get f() { return this.form.controls; }
}
