import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../../../core/services/data.service';
import { Contract, PurchaseOrder, Supplier, IssueItem } from '../../../../core/models/models';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-procurement',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './procurement.component.html',
  styleUrls: ['./procurement.component.css']
})
export class ProcurementComponent implements OnInit {
  projectId = '';
  activeTab = 'contracts';
  contracts: Contract[] = [];
  purchaseOrders: PurchaseOrder[] = [];
  suppliers: Supplier[] = [];
  issueItems: IssueItem[] = [];

  showModal = false;
  editMode = false;
  selectedItem: any = null;
  form!: FormGroup;
  searchTerm = '';

  totalContracts = 8;
  totalPOs = 24;
  totalReceived = 18;
  totalIssues = 12;
  totalSpent = 215450000;

  constructor(private route: ActivatedRoute, private data: DataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.route.parent?.params.subscribe(params => {
      this.projectId = params['id'];
      this.data.getContracts(this.projectId).subscribe(c => this.contracts = c);
      this.data.getPurchaseOrders(this.projectId).subscribe(p => this.purchaseOrders = p);
      this.data.getSuppliers().subscribe(s => this.suppliers = s);
      this.data.getIssueItems(this.projectId).subscribe(i => this.issueItems = i);
    });
  }

  setTab(t: string) { this.activeTab = t; this.closeModal(); }

  // ---- CONTRACTS ----
  initContractForm(c?: Contract) {
    this.form = this.fb.group({
      contractNo: [c?.contractNo || '', Validators.required],
      contractor: [c?.contractor || '', Validators.required],
      category: [c?.category || '', Validators.required],
      value: [c?.value || '', [Validators.required, Validators.min(1)]],
      currency: [c?.currency || 'TZS', Validators.required],
      startDate: [c?.startDate || '', Validators.required],
      endDate: [c?.endDate || '', Validators.required],
      status: [c?.status || 'Pending', Validators.required],
      description: [c?.description || '']
    });
  }

  openAddContract() { this.editMode = false; this.initContractForm(); this.showModal = true; }
  openEditContract(c: Contract) { this.editMode = true; this.selectedItem = c; this.initContractForm(c); this.showModal = true; }

  onSubmitContract() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value;
    if (this.editMode && this.selectedItem) {
      this.data.updateContract({ ...this.selectedItem, ...val });
      Swal.fire({ icon: 'success', title: 'Updated!', timer: 1500, showConfirmButton: false });
    } else {
      this.data.addContract({ id: this.data.generateId('CON'), projectId: this.projectId, ...val });
      Swal.fire({ icon: 'success', title: 'Added!', timer: 1500, showConfirmButton: false });
    }
    this.closeModal();
  }

  deleteContract(c: Contract) {
    Swal.fire({ title: 'Delete Contract?', text: `Delete "${c.contractNo}"?`, icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444' })
      .then(r => { if (r.isConfirmed) { this.data.deleteContract(c.id); Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false }); } });
  }

  // ---- PURCHASE ORDERS ----
  initPOForm(p?: PurchaseOrder) {
    this.form = this.fb.group({
      poNo: [p?.poNo || '', Validators.required],
      supplier: [p?.supplier || '', Validators.required],
      description: [p?.description || '', Validators.required],
      amount: [p?.amount || '', [Validators.required, Validators.min(1)]],
      currency: [p?.currency || 'TZS', Validators.required],
      date: [p?.date || '', Validators.required],
      status: [p?.status || 'Open', Validators.required]
    });
  }

  openAddPO() { this.editMode = false; this.initPOForm(); this.showModal = true; }
  openEditPO(p: PurchaseOrder) { this.editMode = true; this.selectedItem = p; this.initPOForm(p); this.showModal = true; }

  onSubmitPO() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const val = this.form.value;
    if (this.editMode && this.selectedItem) {
      this.data.updatePurchaseOrder({ ...this.selectedItem, ...val });
      Swal.fire({ icon: 'success', title: 'Updated!', timer: 1500, showConfirmButton: false });
    } else {
      this.data.addPurchaseOrder({ id: this.data.generateId('PO'), projectId: this.projectId, ...val });
      Swal.fire({ icon: 'success', title: 'Added!', timer: 1500, showConfirmButton: false });
    }
    this.closeModal();
  }

  deletePO(p: PurchaseOrder) {
    Swal.fire({ title: 'Delete PO?', text: `Delete "${p.poNo}"?`, icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444' })
      .then(r => { if (r.isConfirmed) { this.data.deletePurchaseOrder(p.id); Swal.fire({ icon: 'success', title: 'Deleted!', timer: 1200, showConfirmButton: false }); } });
  }

  closeModal() { this.showModal = false; this.selectedItem = null; }

  getStatusClass(s: string): string {
    const m: any = { 'Active': 'status-active', 'Completed': 'status-completed', 'Pending': 'status-pending', 'Terminated': 'status-overdue', 'Open': 'status-in-progress', 'Received': 'status-completed', 'Partial': 'status-pending', 'Closed': 'status-completed' };
    return m[s] || 'status-pending';
  }

  formatCurrency(n: number): string { return this.data.formatCurrency(n); }
  get f() { return this.form.controls; }
  get topSuppliers(): Supplier[] { return this.suppliers.slice(0, 5); }
}
